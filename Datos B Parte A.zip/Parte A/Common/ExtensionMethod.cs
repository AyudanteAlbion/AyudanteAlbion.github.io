using StatisticsAnalysisTool.Enumerations;
using StatisticsAnalysisTool.Localization;
using StatisticsAnalysisTool.Models.NetworkModel;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows;

namespace StatisticsAnalysisTool.Common;

public static class ExtensionMethod
{
    public static string SetYesOrNo(this bool value)
    {
        return (value) ? LocalizationController.Translation("YES") : LocalizationController.Translation("NO");
    }

    public static void OrderByReference<T>(this ObservableCollection<T> collection, List<T> comparison)
    {
        if (collection == null || comparison == null)
        {
            return;
        }

        var maxCount = Math.Min(collection.Count, comparison.Count);
        for (var i = 0; i < maxCount; i++)
        {
            if (!EqualityComparer<T>.Default.Equals(comparison[i], collection[i]))
            {
                var index = collection.IndexOf(comparison[i]);
                if (index >= 0)
                {
                    collection.Move(index, i);
                }
            }
        }
    }

    public static Dictionary<int, T> ToDictionary<T>(this IEnumerable<T> array)
    {
        if (array == null)
        {
            return new Dictionary<int, T>();
        }

        return array
            .Select((v, i) => new { Key = i, Value = v })
            .ToDictionary(o => o.Key, o => o.Value);
    }

    public static string ToTimerString(this TimeSpan span)
    {
        var hours = (span.Days * 24) + span.Hours;
        return $"{hours:00}:{span.Minutes:00}:{span.Seconds:00}";
    }

    public static string ToTimerString(this int seconds)
    {
        var span = new TimeSpan(0, 0, 0, seconds);
        return span.ToTimerString();
    }

    public static Visibility BoolToVisibility(this bool status)
    {
        return (status) ? Visibility.Visible : Visibility.Collapsed;
    }

    public static Visibility BoolToVisibility(this bool? status)
    {
        return (status ?? false).BoolToVisibility();
    }

    public static double GetValuePerHour(this double value, double seconds)
    {
        if (seconds <= 0)
        {
            return double.MaxValue;
        }

        double hours = seconds / 3600d;
        return value / hours;
    }

    public static bool HasProperty(this object obj, string propertyName)
    {
        if (obj == null || string.IsNullOrWhiteSpace(propertyName))
        {
            return false;
        }

        return obj.GetType().GetProperty(propertyName) != null;
    }

    #region Object to

    public static Guid? ObjectToGuid(this object value)
    {
        try
        {
            if (value is IEnumerable valueEnumerable)
            {
                var myBytes = valueEnumerable.OfType<byte>().ToArray();
                return new Guid(myBytes);
            }
        }
        catch
        {
            return null;
        }

        return null;
    }

    public static ulong? ObjectToUlong(this object value)
    {
        return value switch
        {
            byte byteValue => byteValue,
            ushort ushortValue => ushortValue,
            uint uintValue => uintValue,
            ulong ulongValue => ulongValue,
            short shortValue when shortValue >= 0 => (ulong) shortValue,
            int intValue when intValue >= 0 => (ulong) intValue,
            long longValue when longValue >= 0 => (ulong) longValue,
            _ => null
        };
    }

    public static long? ObjectToLong(this object value)
    {
        return value switch
        {
            byte byteValue => byteValue,
            short shortValue => shortValue,
            ushort ushortValue => ushortValue,
            int intValue => intValue,
            uint uintValue => uintValue,
            long longValue => longValue,
            _ => null
        };
    }

    public static int ObjectToInt(this object value)
    {
        return value switch
        {
            byte byteValue => byteValue,
            short shortValue => shortValue,
            ushort ushortValue => ushortValue,
            int intValue => intValue,
            uint uintValue when uintValue <= int.MaxValue => (int) uintValue,
            long longValue when longValue is >= int.MinValue and <= int.MaxValue => (int) longValue,
            _ => 0
        };
    }

    public static short ObjectToShort(this object value)
    {
        return value switch
        {
            byte byteValue => byteValue,
            short shortValue => shortValue,
            ushort ushortValue when ushortValue <= short.MaxValue => (short) ushortValue,
            int intValue when intValue is >= short.MinValue and <= short.MaxValue => (short) intValue,
            long longValue when longValue is >= short.MinValue and <= short.MaxValue => (short) longValue,
            _ => 0
        };
    }

    public static byte ObjectToByte(this object value)
    {
        return value switch
        {
            byte byteValue => byteValue,
            short shortValue when shortValue is >= byte.MinValue and <= byte.MaxValue => (byte) shortValue,
            int intValue when intValue is >= byte.MinValue and <= byte.MaxValue => (byte) intValue,
            long longValue when longValue is >= byte.MinValue and <= byte.MaxValue => (byte) longValue,
            _ => 0
        };
    }

    public static bool ObjectToBool(this object value)
    {
        return value as bool? ?? false;
    }

    public static double ObjectToDouble(this object value)
    {
        return value switch
        {
            byte byteValue => byteValue,
            short shortValue => shortValue,
            ushort ushortValue => ushortValue,
            int intValue => intValue,
            uint uintValue => uintValue,
            long longValue => longValue,
            float floatValue => floatValue,
            double doubleValue => doubleValue,
            _ => 0
        };
    }

    public static Dictionary<int, T> ToDictionary<T>(this T[] array)
    {
        if (array == null)
        {
            return new Dictionary<int, T>();
        }

        var dict = new Dictionary<int, T>();
        for (int i = 0; i < array.Length; i++)
        {
            dict[i] = array[i];
        }
        return dict;
    }

    #endregion

    #region Number manipulation

    public static string ToShortNumberString(this object num)
    {
        if (num is long l)
        {
            return GetShortNumber(l);
        }

        if (num is int i)
        {
            return GetShortNumber(i);
        }

        if (num is not double d)
        {
            return double.MaxValue.ToString(CultureInfo.InvariantCulture);
        }

        if (double.IsNaN(d))
        {
            return "0";
        }

        return double.IsInfinity(d) ? double.MaxValue.ToString(CultureInfo.InvariantCulture) : GetShortNumber((decimal) d);

    }

    public static double ToShortNumber(this double num, double maxNumber = double.MaxValue)
    {
        try
        {
            if (double.IsNaN(num))
            {
                return maxNumber;
            }

            return double.IsInfinity(num) ? maxNumber : num;
        }
        catch (OverflowException)
        {
            return maxNumber;
        }
    }

    public static string ToChartTooltipNumberString(this double value)
    {
        if (double.IsNaN(value))
        {
            return 0d.ToString("N0", CultureInfo.CurrentCulture);
        }

        if (double.IsInfinity(value))
        {
            return double.MaxValue.ToString("N0", CultureInfo.CurrentCulture);
        }

        return Math.Round(value).ToString("N0", CultureInfo.CurrentCulture);
    }

    public static string GetShortNumber(this decimal num, CultureInfo culture = null)
    {
        culture ??= CultureInfo.CurrentCulture;

        if (num < -10000000)
        {
            num /= 10000;
            return (num / 100m).ToString("#.##'M'", culture);
        }

        if (num < -1000000)
        {
            num /= 100;
            return (num / 10m).ToString("#.##'K'", culture);
        }

        if (num < -10000)
        {
            num /= 10;
            return (num / 100m).ToString("#.##'K'", culture);
        }

        if (num < 1000)
        {
            return num.ToString("N0", culture);
        }

        if (num < 10000)
        {
            num /= 10;
            return (num / 100m).ToString("#.##'K'", culture);
        }

        if (num < 1000000)
        {
            num /= 100;
            return (num / 10m).ToString("#.##'K'", culture);
        }

        if (num < 10000000)
        {
            num /= 10000;
            return (num / 100m).ToString("#.##'M'", culture);
        }

        num /= 100000;
        return (num / 10m).ToString("#.##'M'", culture);
    }

    public static double ToPositive(this double value)
    {
        return value > 0 ? value : -value;
    }

    public static double ToPositiveFromNegativeOrZero(this double healthChange)
    {
        return healthChange >= 0d ? 0d : healthChange.ToPositive();
    }

    #endregion

    #region Player Objects

    public static long GetCurrentTotalDamage(this List<KeyValuePair<Guid, PlayerGameObject>> playerObjects)
    {
        return playerObjects.Count <= 0 ? 0 : playerObjects.Max(x => x.Value.Damage);
    }

    public static long GetCurrentTotalHeal(this List<KeyValuePair<Guid, PlayerGameObject>> playerObjects)
    {
        return playerObjects.Count <= 0 ? 0 : playerObjects.Max(x => x.Value.Heal);
    }

    public static long GetCurrentTotalTakenDamage(this List<KeyValuePair<Guid, PlayerGameObject>> playerObjects)
    {
        return playerObjects.Count <= 0 ? 0 : playerObjects.Max(x => x.Value.TakenDamage);
    }


    public static double GetDamagePercentage(this List<KeyValuePair<Guid, PlayerGameObject>> playerObjects, double playerDamage)
    {
        var totalDamage = playerObjects.Sum(x => x.Value.Damage);
        return totalDamage > 0 ? playerDamage / totalDamage * 100 : 0;
    }

    public static double GetHealPercentage(this List<KeyValuePair<Guid, PlayerGameObject>> playerObjects, double playerHeal)
    {
        var totalHeal = playerObjects.Sum(x => x.Value.Heal);
        return totalHeal > 0 ? playerHeal / totalHeal * 100 : 0;
    }

    public static double GetTakenDamagePercentage(this List<KeyValuePair<Guid, PlayerGameObject>> playerObjects, double playerDamage)
    {
        var totalTakenDamage = playerObjects.Sum(x => x.Value.TakenDamage);
        return totalTakenDamage > 0 ? playerDamage / totalTakenDamage * 100 : 0;
    }

    #endregion

    #region DateTime

    public static string CurrentDateTimeFormat(this DateTime value)
    {
        return DateTime.SpecifyKind(value, DateTimeKind.Utc).ToLocalTime()
            .ToString("G", CultureInfo.DefaultThreadCurrentCulture);
    }

    public static string DateTimeToLastUpdateTime(this DateTime dateTime)
    {
        var endTime = DateTime.UtcNow;
        var timeSpan = endTime - dateTime;
        var minutes = timeSpan.TotalMinutes;
        var hours = timeSpan.TotalHours;
        var days = timeSpan.TotalDays;

        if (minutes <= 120) return $"{minutes:N0} {LocalizationController.Translation("MINUTES")}";

        if (hours <= 48) return $"{hours:N0} {LocalizationController.Translation("HOURS")}";

        if (days <= 365) return $"{days:N0} {LocalizationController.Translation("DAYS")}";

        return $"{LocalizationController.Translation("OVER_A_YEAR")}";
    }

    public static ValueTimeStatus GetValueTimeStatus(this DateTime dateTime)
    {
        if (dateTime.Date <= DateTime.MinValue.Date)
        {
            return ValueTimeStatus.NoValue;
        }

        var currentDateTime = DateTime.UtcNow;

        if (dateTime.AddHours(8) <= currentDateTime)
        {
            return ValueTimeStatus.ToOldThird;
        }

        if (dateTime.AddHours(4) <= currentDateTime)
        {
            return ValueTimeStatus.ToOldSecond;
        }

        if (dateTime.AddHours(2) <= currentDateTime)
        {
            return ValueTimeStatus.ToOldFirst;
        }

        return ValueTimeStatus.Normal;
    }

    public static PastTime GetPastTimeEnumByDateTime(this DateTime dateTime)
    {
        var currentDateTime = DateTime.UtcNow;

        if (dateTime.Date <= DateTime.MinValue.Date)
        {
            return PastTime.Unknown;
        }

        if (dateTime.AddDays(30) <= currentDateTime)
        {
            return PastTime.VeryVeryOld;
        }

        if (dateTime.AddDays(7) <= currentDateTime)
        {
            return PastTime.VeryOld;
        }

        if (dateTime.AddHours(24) <= currentDateTime)
        {
            return PastTime.Old;
        }

        if (dateTime.AddHours(8) <= currentDateTime)
        {
            return PastTime.BitOld;
        }

        if (dateTime.AddHours(4) <= currentDateTime)
        {
            return PastTime.LittleNew;
        }

        if (dateTime.AddHours(2) <= currentDateTime)
        {
            return PastTime.AlmostNew;
        }

        return PastTime.New;
    }

    public static bool IsDateInWeekOfYear(this DateTime date1, DateTime date2)
    {
        return date1.Year == date2.Year && ISOWeek.GetWeekOfYear(date1) == ISOWeek.GetWeekOfYear(date2);
    }

    public static bool IsDateInSameMonth(this DateTime date1, DateTime date2)
    {
        return date1.Year == date2.Year && date1.Month == date2.Month;
    }

    public static bool TickCompare(this long ticks1, long ticks2, double toleranceInMilliseconds)
    {
        var tolerance = TimeSpan.FromMilliseconds(toleranceInMilliseconds);
        var difference = ticks1 - ticks2;

        return Math.Abs(difference) <= tolerance.Ticks;
    }

    #endregion

    #region Json

    public static async Task<string> SerializeJsonStringAsync(this object obj, JsonSerializerOptions option = null)
    {
        using var stream = new MemoryStream();
        await JsonSerializer.SerializeAsync(stream, obj, obj.GetType(), option);
        stream.Position = 0;
        using var reader = new StreamReader(stream);
        return await reader.ReadToEndAsync();
    }

    #endregion

    #region List / Collection / Array

    public static bool IsInBounds<T>(this IEnumerable<T> array, long index)
    {
        if (array == null)
        {
            return false;
        }

        return index >= 0 && index < array.Count();
    }

    public static void SortByDescending<T, TKey>(this ObservableCollection<T> collection, Func<T, TKey> keySelector)
    {
        var sorted = collection.OrderByDescending(keySelector).ToList();
        for (int i = 0; i < sorted.Count; i++)
        {
            collection.Move(collection.IndexOf(sorted[i]), i);
        }
    }

    public static void SortByDescending<T, TKey>(this List<T> list, Func<T, TKey> keySelector)
    {
        list.Sort((x, y) => Comparer<TKey>.Default.Compare(keySelector(y), keySelector(x)));
    }

    public static void SortByAscending<T, TKey>(this ObservableCollection<T> collection, Func<T, TKey> keySelector)
    {
        var sorted = collection.OrderBy(keySelector).ToList();
        for (int i = 0; i < sorted.Count; i++)
        {
            collection.Move(collection.IndexOf(sorted[i]), i);
        }
    }

    public static void SortByAscending<T, TKey>(this List<T> list, Func<T, TKey> keySelector)
    {
        list.Sort((x, y) => Comparer<TKey>.Default.Compare(keySelector(x), keySelector(y)));
    }

    #endregion
}
