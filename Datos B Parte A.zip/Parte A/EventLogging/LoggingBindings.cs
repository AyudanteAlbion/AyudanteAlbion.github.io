﻿using Ookii.Dialogs.Wpf;
using StatisticsAnalysisTool.Common;
using StatisticsAnalysisTool.Common.UserSettings;
using StatisticsAnalysisTool.EventLogging.Notification;
using StatisticsAnalysisTool.Localization;
using StatisticsAnalysisTool.Models;
using StatisticsAnalysisTool.Models.TranslationModel;
using StatisticsAnalysisTool.ViewModels;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Data;
using System.Windows.Input;

namespace StatisticsAnalysisTool.EventLogging;

public class LoggingBindings : BaseViewModel
{
    private CancellationTokenSource _cancellationTokenSource = new();
    private ObservableCollection<LootingPlayer> _lootingPlayers = new();
    private readonly LootComparatorSaveService _lootComparatorSaveService = new();
    private readonly HashSet<LootingPlayer> _subscribedLootingPlayers = [];
    private bool _isShowingLost = true;
    private bool _isShowingResolved = true;
    private bool _isShowingDonated = true;
    private bool _isShowingTrash = true;
    private bool _isShowingT1ToT3 = true;
    private bool _isShowingT4 = true;
    private bool _isShowingT5 = true;
    private bool _isShowingT6 = true;
    private bool _isShowingT7 = true;
    private bool _isShowingT8 = true;
    private bool _isShowingBag = true;
    private bool _isShowingCape = true;
    private bool _isShowingWeapon = true;
    private bool _isShowingArmor = true;
    private bool _isShowingFood = true;
    private bool _isShowingPotion = true;
    private bool _isShowingMount = true;
    private bool _isShowingOthers = true;
    private bool _isUpdatingLootComparatorGuildFilters;
    private bool _isCompareButtonEnabled = true;
    // Clock-offset detection searches up to five minutes and trusts a single sample only up to ten seconds.
    // Samples within one second form the dominant offset; after normalization, timestamps may differ by one second.
    private const double LootLogResidualTimeToleranceSeconds = 1;
    private const double LootLogOffsetGroupingToleranceSeconds = 1;
    private const double LootLogSingleMatchOffsetLimitSeconds = 10;
    private const double LootLogOffsetSearchLimitSeconds = 300;
    private static readonly string[] LootLogHeaderColumns =
    [
        "timestamp_utc",
        "looted_by__alliance",
        "looted_by__guild",
        "looted_by__name",
        "item_id",
        "item_name",
        "quantity",
        "looted_from__alliance",
        "looted_from__guild",
        "looted_from__name"
    ];
    private int _chestLogSourceCount;
    private int _lootLogFileCount;

    public LoggingBindings()
    {
        IsLoggingTrackingActive = SettingsController.CurrentSettings.IsLoggingTrackingActive;
        IsLootComparatorTrackingActive = SettingsController.CurrentSettings.IsLootComparatorTrackingActive;
        SubscribeLootingPlayers(_lootingPlayers);
    }

    public void Init()
    {
        RefreshLootComparatorSaves();
        LootingPlayersCollectionView = CollectionViewSource.GetDefaultView(LootingPlayers) as ListCollectionView;

        TopLootersCollectionView = CollectionViewSource.GetDefaultView(TopLooters) as ListCollectionView;
        if (TopLootersCollectionView != null)
        {
            TopLootersCollectionView.IsLiveSorting = true;
            TopLootersCollectionView.CustomSort = new TopLooterComparer();
        }

        ClearFilters();

        AddFilter(new LoggingFilterObject(LoggingFilterType.Fame)
        {
            IsSelected = SettingsController.CurrentSettings.IsMainTrackerFilterFame,
            Name = MainWindowTranslation.Fame
        });

        AddFilter(new LoggingFilterObject(LoggingFilterType.Silver)
        {
            IsSelected = SettingsController.CurrentSettings.IsMainTrackerFilterSilver,
            Name = MainWindowTranslation.Silver
        });

        AddFilter(new LoggingFilterObject(LoggingFilterType.Faction)
        {
            IsSelected = SettingsController.CurrentSettings.IsMainTrackerFilterFaction,
            Name = MainWindowTranslation.Faction
        });

        AddFilter(new LoggingFilterObject(LoggingFilterType.ConsumableLoot)
        {
            IsSelected = SettingsController.CurrentSettings.IsMainTrackerFilterConsumableLoot,
            Name = MainWindowTranslation.ConsumableLoot
        });

        AddFilter(new LoggingFilterObject(LoggingFilterType.EquipmentLoot)
        {
            IsSelected = SettingsController.CurrentSettings.IsMainTrackerFilterEquipmentLoot,
            Name = MainWindowTranslation.EquipmentLoot
        });

        AddFilter(new LoggingFilterObject(LoggingFilterType.SimpleLoot)
        {
            IsSelected = SettingsController.CurrentSettings.IsMainTrackerFilterSimpleLoot,
            Name = MainWindowTranslation.SimpleLoot
        });

        AddFilter(new LoggingFilterObject(LoggingFilterType.UnknownLoot)
        {
            IsSelected = SettingsController.CurrentSettings.IsMainTrackerFilterUnknownLoot,
            Name = MainWindowTranslation.UnknownLoot
        });

        AddFilter(new LoggingFilterObject(LoggingFilterType.ShowLootFromMob)
        {
            IsSelected = SettingsController.CurrentSettings.IsLootFromMobShown,
            Name = MainWindowTranslation.ShowLootFromMobs
        });

        AddFilter(new LoggingFilterObject(LoggingFilterType.Kill)
        {
            IsSelected = SettingsController.CurrentSettings.IsMainTrackerFilterKill,
            Name = MainWindowTranslation.ShowKills
        });

        OnPropertyChanged(nameof(IsAllNotificationFilterSelected));
    }

    private void AddFilter(LoggingFilterObject filter)
    {
        filter.PropertyChanged += FilterPropertyChanged;
        Filters.Add(filter);
    }

    private void ClearFilters()
    {
        foreach (var filter in Filters)
        {
            filter.PropertyChanged -= FilterPropertyChanged;
        }

        Filters.Clear();
    }

    private void FilterPropertyChanged(object sender, PropertyChangedEventArgs args)
    {
        if (args.PropertyName == nameof(LoggingFilterObject.IsSelected))
        {
            OnPropertyChanged(nameof(NotificationFilterSummary));
            OnPropertyChanged(nameof(IsAllNotificationFilterSelected));
        }
    }

    public bool IsAllNotificationFilterSelected => Filters.Count > 0 && Filters.All(filter => filter.IsSelected != true);

    public void UpdateAllNotificationFilterSelection(bool isSelected)
    {
        if (isSelected)
        {
            foreach (var filter in Filters)
            {
                if (filter.IsSelected != true)
                {
                    continue;
                }

                filter.IsSelected = false;
            }
        }

        OnPropertyChanged(nameof(IsAllNotificationFilterSelected));
    }

    private void SubscribeLootingPlayers(ObservableCollection<LootingPlayer> lootingPlayers)
    {
        lootingPlayers.CollectionChanged += LootingPlayersCollectionChanged;

        foreach (var lootingPlayer in lootingPlayers)
        {
            SubscribeLootingPlayer(lootingPlayer);
        }
    }

    private void UnsubscribeLootingPlayers(ObservableCollection<LootingPlayer> lootingPlayers)
    {
        lootingPlayers.CollectionChanged -= LootingPlayersCollectionChanged;

        foreach (var lootingPlayer in lootingPlayers)
        {
            UnsubscribeLootingPlayer(lootingPlayer);
        }
    }

    private void LootingPlayersCollectionChanged(object sender, NotifyCollectionChangedEventArgs args)
    {
        if (args.Action == NotifyCollectionChangedAction.Reset)
        {
            foreach (var lootingPlayer in _subscribedLootingPlayers.Except(LootingPlayers).ToList())
            {
                UnsubscribeLootingPlayer(lootingPlayer);
            }
        }

        if (args.OldItems is not null)
        {
            foreach (LootingPlayer oldPlayer in args.OldItems)
            {
                UnsubscribeLootingPlayer(oldPlayer);
            }
        }

        if (args.NewItems is not null)
        {
            foreach (LootingPlayer newPlayer in args.NewItems)
            {
                SubscribeLootingPlayer(newPlayer);
            }
        }

        RefreshLootComparatorGuildFilters();
    }

    private void SubscribeLootingPlayer(LootingPlayer lootingPlayer)
    {
        if (!_subscribedLootingPlayers.Add(lootingPlayer))
        {
            return;
        }

        lootingPlayer.PropertyChanged += LootingPlayerPropertyChanged;
    }

    private void UnsubscribeLootingPlayer(LootingPlayer lootingPlayer)
    {
        if (!_subscribedLootingPlayers.Remove(lootingPlayer))
        {
            return;
        }

        lootingPlayer.PropertyChanged -= LootingPlayerPropertyChanged;
    }

    private void LootingPlayerPropertyChanged(object sender, PropertyChangedEventArgs args)
    {
        if (args.PropertyName == nameof(LootingPlayer.PlayerGuild))
        {
            RefreshLootComparatorGuildFilters();
        }
    }

    #region Loot comparator

    public async Task CompareLootLogsAsync()
    {
        if (!IsCompareButtonEnabled)
        {
            return;
        }

        IsCompareButtonEnabled = false;

        try
        {
            await UpdateItemsStatusAsync();
        }
        finally
        {
            IsCompareButtonEnabled = true;
        }
    }

    public async Task UpdateItemsStatusAsync()
    {
        RemoveAllVaultItems();

        var lootingPlayerSnapshots = CreateLootingPlayerSnapshots(LootingPlayers);
        var vaultLogSnapshot = VaultLogItems.ToList();
        var vaultLogItems = await Task.Run(() => CreateVaultLogItems(vaultLogSnapshot));
        var comparisonResult = await Task.Run(() => BuildLootComparisonResult(lootingPlayerSnapshots, vaultLogItems));

        ApplyLootComparisonResult(comparisonResult);
        await UpdateFilteredLootedItemsAsync();
        RefreshLootComparatorLogCounts();
    }

    public void UpdateItemsStatus()
    {
        RemoveAllVaultItems();

        var lootingPlayerSnapshots = CreateLootingPlayerSnapshots(LootingPlayers);
        var vaultLogItems = CreateVaultLogItems(VaultLogItems.ToList());
        var comparisonResult = BuildLootComparisonResult(lootingPlayerSnapshots, vaultLogItems);

        ApplyLootComparisonResult(comparisonResult);
        ApplyLootComparatorFilters();
        RefreshLootComparatorLogCounts();
    }

    private static List<LootingPlayerSnapshot> CreateLootingPlayerSnapshots(IEnumerable<LootingPlayer> lootingPlayers)
    {
        return lootingPlayers
            .Select(lootingPlayer => new LootingPlayerSnapshot(lootingPlayer, lootingPlayer.PlayerName, lootingPlayer.GetLootedItemsSnapshot()))
            .ToList();
    }

    private static LootComparisonResult BuildLootComparisonResult(
        IReadOnlyCollection<LootingPlayerSnapshot> lootingPlayerSnapshots,
        IReadOnlyCollection<(VaultContainerLogItem LogItem, Item Item, LootedItem LootedItem)> vaultLogItems)
    {
        var result = new LootComparisonResult();
        var keyComparer = new LootItemKeyComparer();
        var lootingPlayersByName = lootingPlayerSnapshots
            .Where(snapshot => !string.IsNullOrWhiteSpace(snapshot.PlayerName))
            .GroupBy(snapshot => snapshot.PlayerName, StringComparer.OrdinalIgnoreCase)
            .ToDictionary(group => group.Key, group => group.First(), StringComparer.OrdinalIgnoreCase);
        var lootLogItems = lootingPlayerSnapshots
            .SelectMany(snapshot => snapshot.LootedItems)
            .Where(item => !item.IsItemFromVaultLog)
            .ToList();
        var lootCandidatesByKey = lootLogItems
            .GroupBy(item => new LootItemKey(item.LootedByName, item.ItemIndex, item.Quantity), keyComparer)
            .ToDictionary(
                group => group.Key,
                group => group.OrderByDescending(item => ToUtc(item.UtcPickupTime)).ToList(),
                keyComparer);
        var matchedItems = new HashSet<LootedItem>();
        var lastLootLogTime = GetLastLootLogTime(lootLogItems);

        foreach (var lootLogItem in lootLogItems)
        {
            result.Statuses[lootLogItem] = LootedItemStatus.Unknown;
        }

        foreach (var (logItem, vaultLogLocalizedItem, vaultLogItem) in vaultLogItems.OrderBy(item => ToUtc(item.LootedItem.UtcPickupTime)))
        {
            lootingPlayersByName.TryGetValue(logItem.PlayerName, out var lootingPlayerSnapshot);

            var status = IsAfterLastLootLog(vaultLogItem, lastLootLogTime)
                ? LootedItemStatus.Donated
                : LootedItemStatus.Ignored;

            if (TryMatchLootedItem(lootCandidatesByKey, matchedItems, vaultLogItem, out var matchedItem))
            {
                result.Statuses[matchedItem] = LootedItemStatus.Resolved;
                continue;
            }

            result.Additions.Add(new LootComparisonAddition(lootingPlayerSnapshot?.Player, CreateVaultLogLootedItem(logItem, vaultLogLocalizedItem, status), logItem.PlayerName));
        }

        MarkLostItems(result.Statuses, lootLogItems);

        return result;
    }

    private static bool TryMatchLootedItem(
        IReadOnlyDictionary<LootItemKey, List<LootedItem>> lootCandidatesByKey,
        ISet<LootedItem> matchedItems,
        LootedItem vaultLogItem,
        out LootedItem matchedItem)
    {
        matchedItem = null;
        var key = new LootItemKey(vaultLogItem.LootedByName, vaultLogItem.ItemIndex, vaultLogItem.Quantity);

        if (!lootCandidatesByKey.TryGetValue(key, out var candidates))
        {
            return false;
        }

        matchedItem = candidates.FirstOrDefault(candidate =>
            !matchedItems.Contains(candidate)
            && ToUtc(candidate.UtcPickupTime) < ToUtc(vaultLogItem.UtcPickupTime));

        if (matchedItem is null)
        {
            return false;
        }

        matchedItems.Add(matchedItem);
        return true;
    }

    private void ApplyLootComparisonResult(LootComparisonResult comparisonResult)
    {
        var lootingPlayersByName = LootingPlayers
            .Where(player => !string.IsNullOrWhiteSpace(player.PlayerName))
            .GroupBy(player => player.PlayerName, StringComparer.OrdinalIgnoreCase)
            .ToDictionary(group => group.Key, group => group.First(), StringComparer.OrdinalIgnoreCase);

        foreach (var (item, status) in comparisonResult.Statuses)
        {
            item.Status = status;
        }

        foreach (var addition in comparisonResult.Additions)
        {
            if (addition.LootingPlayer is not null)
            {
                addition.LootingPlayer.AddLootedItem(addition.LootedItem);
                continue;
            }

            if (lootingPlayersByName.TryGetValue(addition.PlayerName, out var existingPlayer))
            {
                existingPlayer.AddLootedItem(addition.LootedItem);
                continue;
            }

            var newPlayer = AddNewPlayerToLootingPlayers(addition.PlayerName, addition.LootedItem);
            if (!string.IsNullOrWhiteSpace(newPlayer.PlayerName))
            {
                lootingPlayersByName[newPlayer.PlayerName] = newPlayer;
            }
        }
    }

    private static DateTime? GetLastLootLogTime(IEnumerable<LootedItem> lootLogItems)
    {
        return lootLogItems
            .Select(item => (DateTime?) ToUtc(item.UtcPickupTime))
            .Max();
    }

    private static List<(VaultContainerLogItem LogItem, Item Item, LootedItem LootedItem)> CreateVaultLogItems(IEnumerable<VaultContainerLogItem> logItems)
    {
        var vaultLogItems = new List<(VaultContainerLogItem, Item, LootedItem)>();

        foreach (var logItem in logItems)
        {
            var vaultLogLocalizedItem = ItemController.GetItemByLocalizedName(logItem.LocalizedName, logItem.Enchantment);
            if (vaultLogLocalizedItem is null)
            {
                continue;
            }

            vaultLogItems.Add((logItem, vaultLogLocalizedItem, new LootedItem
            {
                UtcPickupTime = ToUtc(logItem.Timestamp),
                ItemIndex = vaultLogLocalizedItem.Index,
                IsItemFromVaultLog = true,
                IsTrash = IsTrashItem(vaultLogLocalizedItem),
                LootedByName = logItem.PlayerName,
                Quantity = logItem.Quantity
            }));
        }

        return vaultLogItems;
    }

    private static bool IsAfterLastLootLog(LootedItem vaultLogItem, DateTime? lastLootLogTime)
    {
        return lastLootLogTime is null || vaultLogItem.UtcPickupTime > lastLootLogTime.Value;
    }

    private static LootedItem CreateVaultLogLootedItem(VaultContainerLogItem logItem, Item vaultLogLocalizedItem, LootedItemStatus status)
    {
        return new LootedItem
        {
            UtcPickupTime = ToUtc(logItem.Timestamp),
            ItemIndex = vaultLogLocalizedItem.Index,
            IsItemFromVaultLog = true,
            IsTrash = IsTrashItem(vaultLogLocalizedItem),
            LootedByName = logItem.PlayerName,
            Quantity = logItem.Quantity,
            Status = status
        };
    }

    private LootingPlayer AddNewPlayerToLootingPlayers(string playerName, LootedItem lootedItem)
    {
        var lootingPlayer = new LootingPlayer()
        {
            PlayerName = playerName,
            LootingPlayerVisibility = Visibility.Visible,
            LootedItems =
            [
                lootedItem
            ]
        };

        LootingPlayers.Add(lootingPlayer);
        return lootingPlayer;
    }

    public void RemoveAllVaultItems()
    {
        var playerToRemove = new List<LootingPlayer>();
        foreach (var player in LootingPlayers.ToList())
        {
            var itemsToRemove = player.GetLootedItemsSnapshot().Where(item => item.IsItemFromVaultLog).ToList();
            player.RemoveLootedItems(itemsToRemove);

            if (player.LootedItemCount <= 0 && !player.HasCombatEvents)
            {
                playerToRemove.Add(player);
            }
        }

        foreach (var player in playerToRemove)
        {
            LootingPlayers.Remove(player);
        }
    }

    private void ResetLootLogItemStatuses()
    {
        foreach (var player in LootingPlayers.ToList())
        {
            foreach (var item in player.GetLootedItemsSnapshot())
            {
                if (!item.IsItemFromVaultLog)
                {
                    item.Status = LootedItemStatus.Unknown;
                }
            }
        }
    }

    public void ClearVaultLogs()
    {
        VaultLogItems.Clear();
        _chestLogSourceCount = 0;
        RemoveAllVaultItems();
        ResetLootLogItemStatuses();
        RefreshLootComparatorLogCounts();
    }

    public void ClearLootLogs()
    {
        LootLogCombatEvents.Clear();
        LootingPlayers.Clear();
        _lootLogFileCount = 0;
        RefreshLootComparatorLogCounts();
    }

    public void ClearAllLootComparatorLogs()
    {
        VaultLogItems.Clear();
        LootLogCombatEvents.Clear();
        LootingPlayers.Clear();
        _chestLogSourceCount = 0;
        _lootLogFileCount = 0;
        ClearLootComparatorImportEventLine();
        RefreshLootComparatorLogCounts();
    }

    public LootComparatorSave SaveLootComparator(string name)
    {
        if (!CanSaveLootComparator)
        {
            throw new InvalidOperationException("At least one chest or loot log must be loaded before creating a loot comparator save.");
        }

        var createdSave = _lootComparatorSaveService.Save(
            name,
            VaultLogItems.ToList(),
            LootingPlayers.ToList(),
            LootLogCombatEvents.ToList());
        RefreshLootComparatorSaves();
        SelectedLootComparatorSave = LootComparatorSaves.FirstOrDefault(save =>
            string.Equals(save.DirectoryPath, createdSave.DirectoryPath, StringComparison.OrdinalIgnoreCase));
        return createdSave;
    }

    public bool LoadSelectedLootComparatorSave()
    {
        var save = SelectedLootComparatorSave;
        if (save is null)
        {
            return false;
        }

        try
        {
            List<VaultContainerLogItem> chestLogItems = [];
            List<ImportedLootLogItem> lootLogItems = [];
            List<LootLogCombatEvent> combatEvents = [];

            if (save.ChestLogEntryCount > 0
                && (!TryReadVaultLogText(File.ReadAllText(save.ChestLogFilePath), out chestLogItems)
                    || chestLogItems.Count != save.ChestLogEntryCount))
            {
                SetLootComparatorImportEventLine(LocalizationController.Translation("LOOT_COMPARATOR_SAVE_LOAD_FAILED"));
                return false;
            }

            if (save.LootLogEntryCount > 0
                && (!TryReadLootLogFile(save.LootLogFilePath, out lootLogItems, out combatEvents)
                    || lootLogItems.Count + combatEvents.Count != save.LootLogEntryCount))
            {
                SetLootComparatorImportEventLine(LocalizationController.Translation("LOOT_COMPARATOR_SAVE_LOAD_FAILED"));
                return false;
            }

            ClearAllLootComparatorLogs();

            var addedChestLogItems = AddVaultLogItems(chestLogItems);
            var addedLootLogItems = AddLootLogItems(lootLogItems);
            var addedCombatEvents = AddLootLogCombatEvents(combatEvents);
            _chestLogSourceCount = addedChestLogItems > 0 ? 1 : 0;
            _lootLogFileCount = addedLootLogItems + addedCombatEvents > 0 ? 1 : 0;

            ClearLootComparatorImportEventLine();
            RefreshLootComparatorLogCounts();
            _ = UpdateFilteredLootedItemsAsync();

            Debug.Print($"Loaded loot comparator save '{save.Name}' with {addedChestLogItems} chest entries, {addedLootLogItems} loot entries and {addedCombatEvents} combat entries.");
            return true;
        }
        catch (Exception ex)
        {
            Debug.Print($"Error loading loot comparator save '{save.Name}': {ex.Message}");
            SetLootComparatorImportEventLine(LocalizationController.Translation("LOOT_COMPARATOR_SAVE_LOAD_FAILED"));
            return false;
        }
    }

    public bool DeleteSelectedLootComparatorSave()
    {
        var save = SelectedLootComparatorSave;
        if (save is null)
        {
            return false;
        }

        var deleted = _lootComparatorSaveService.Delete(save);
        RefreshLootComparatorSaves();
        return deleted;
    }

    public void RefreshLootComparatorSaves()
    {
        var selectedDirectoryPath = SelectedLootComparatorSave?.DirectoryPath;
        LootComparatorSaves.Clear();

        try
        {
            foreach (var save in _lootComparatorSaveService.GetAll())
            {
                LootComparatorSaves.Add(save);
            }
        }
        catch (Exception ex)
        {
            Debug.Print($"Error loading loot comparator save list: {ex.Message}");
        }

        SelectedLootComparatorSave = LootComparatorSaves.FirstOrDefault(save =>
            string.Equals(save.DirectoryPath, selectedDirectoryPath, StringComparison.OrdinalIgnoreCase));
        OnPropertyChanged(nameof(CanSaveLootComparator));
    }

    private static void MarkLostItems(IDictionary<LootedItem, LootedItemStatus> statuses, IEnumerable<LootedItem> lootLogItems)
    {
        var lootLogItemsBySource = lootLogItems
            .Where(item => !string.IsNullOrWhiteSpace(item.LootedFromName))
            .GroupBy(item => new LootItemKey(item.LootedFromName, item.ItemIndex, item.Quantity), new LootItemKeyComparer())
            .ToDictionary(
                group => group.Key,
                group => group.OrderBy(item => ToUtc(item.UtcPickupTime)).ToList(),
                new LootItemKeyComparer());

        foreach (var (item, status) in statuses.ToList())
        {
            if (status != LootedItemStatus.Unknown)
            {
                continue;
            }

            var key = new LootItemKey(item.LootedByName, item.ItemIndex, item.Quantity);
            if (!lootLogItemsBySource.TryGetValue(key, out var laterLoots))
            {
                continue;
            }

            var lootTime = ToUtc(item.UtcPickupTime);
            if (laterLoots.Any(laterLoot => !ReferenceEquals(laterLoot, item) && ToUtc(laterLoot.UtcPickupTime) > lootTime))
            {
                statuses[item] = LootedItemStatus.Lost;
            }
        }
    }

    public void OpenVaultFilePathSelection()
    {
        var dialog = new VistaOpenFileDialog()
        {
            Filter = @"CSV files (*.csv)|*.csv",
            Title = LocalizationController.Translation("SELECT_CHEST_LOG_FILES"),
            Multiselect = true
        };

        IsAllButtonsEnabled = false;
        var result = dialog.ShowDialog();

        if (result.HasValue && result.Value)
        {
            var loadedFiles = LoadVaultLogFiles(dialog.FileNames);

            Debug.Print($"Loaded {loadedFiles} chest log files with {VaultLogItems.Count} chest log entries.");
        }

        IsAllButtonsEnabled = true;
    }

    internal int LoadVaultLogFiles(IEnumerable<string> filePaths)
    {
        var loadedFiles = 0;
        ClearLootComparatorImportEventLine();

        foreach (var filePath in filePaths)
        {
            try
            {
                if (!TryReadVaultLogText(File.ReadAllText(filePath), out var fileItems))
                {
                    SetLootComparatorImportEventLine("LOOT_COMPARATOR_INVALID_CHEST_LOG_FILE", Path.GetFileName(filePath));
                    continue;
                }

                var addedItems = AddVaultLogItems(fileItems);
                if (addedItems > 0)
                {
                    loadedFiles++;
                }
            }
            catch (Exception ex)
            {
                Debug.Print($"Error processing chest log file '{filePath}': {ex.Message}");
                SetLootComparatorImportEventLine("LOOT_COMPARATOR_INVALID_CHEST_LOG_FILE", Path.GetFileName(filePath));
            }
        }

        if (loadedFiles > 0)
        {
            _chestLogSourceCount += loadedFiles;
            RefreshLootComparatorLogCounts();
        }

        return loadedFiles;
    }

    public int AddVaultLogText(string chestLogText)
    {
        ClearLootComparatorImportEventLine();
        if (!TryReadVaultLogText(chestLogText, out var items))
        {
            SetLootComparatorImportEventLine(LocalizationController.Translation("LOOT_COMPARATOR_INVALID_CHEST_LOG_TEXT"));
            Debug.Print("Rejected chest log text because it does not match the expected chest log format.");
            return 0;
        }

        var addedItems = AddVaultLogItems(items);
        if (addedItems > 0)
        {
            _chestLogSourceCount++;
            RefreshLootComparatorLogCounts();
        }

        Debug.Print($"Added {addedItems} chest log entries from pasted chest log text.");

        return addedItems;
    }

    public void OpenLootLogFilePathSelection()
    {
        var dialog = new VistaOpenFileDialog()
        {
            Filter = @"CSV files (*.csv)|*.csv",
            Title = LocalizationController.Translation("SELECT_LOOT_LOG_FILES"),
            Multiselect = true
        };

        IsAllButtonsEnabled = false;
        var result = dialog.ShowDialog();

        if (result.HasValue && result.Value)
        {
            var addedItems = AddLootLogFiles(dialog.FileNames);
            Debug.Print($"Imported {addedItems} loot log entries.");
            _ = UpdateFilteredLootedItemsAsync();
        }

        IsAllButtonsEnabled = true;
    }

    internal int AddLootLogFiles(IEnumerable<string> filePaths)
    {
        var addedItems = 0;
        ClearLootComparatorImportEventLine();

        foreach (var filePath in filePaths)
        {
            try
            {
                if (!TryReadLootLogFile(filePath, out var lootLogItems, out var combatEvents))
                {
                    SetLootComparatorImportEventLine("LOOT_COMPARATOR_INVALID_LOOT_LOG_FILE", Path.GetFileName(filePath));
                    continue;
                }

                var fileAddedLootItems = AddLootLogItems(lootLogItems);
                var fileAddedCombatEvents = AddLootLogCombatEvents(combatEvents);
                var fileAddedEntries = fileAddedLootItems + fileAddedCombatEvents;
                addedItems += fileAddedEntries;

                if (fileAddedEntries > 0)
                {
                    _lootLogFileCount++;
                }
            }
            catch (Exception ex)
            {
                Debug.Print($"Error processing loot log file '{filePath}': {ex.Message}");
                SetLootComparatorImportEventLine("LOOT_COMPARATOR_INVALID_LOOT_LOG_FILE", Path.GetFileName(filePath));
            }
        }

        RefreshLootComparatorLogCounts();
        return addedItems;
    }

    private static bool TryReadLootLogFile(
        string filePath,
        out List<ImportedLootLogItem> lootLogItems,
        out List<LootLogCombatEvent> combatEvents)
    {
        lootLogItems = [];
        combatEvents = [];
        var isHeaderLine = true;

        foreach (var line in File.ReadLines(filePath))
        {
            if (string.IsNullOrWhiteSpace(line))
            {
                continue;
            }

            if (!TrySplitDelimitedLine(line, ';', out var values))
            {
                return false;
            }

            TrimDelimitedValues(values);

            if (isHeaderLine)
            {
                if (!IsLootLogHeader(values))
                {
                    return false;
                }

                isHeaderLine = false;
                continue;
            }

            if (IsNonLootEventRow(values))
            {
                if (!TryParseLootLogCombatEvent(values, out var combatEvent))
                {
                    return false;
                }

                combatEvents.Add(combatEvent);
                continue;
            }

            if (!TryParseLootLogFields(values, out var lootLogItem))
            {
                return false;
            }

            lootLogItems.Add(lootLogItem);
        }

        return !isHeaderLine && lootLogItems.Count + combatEvents.Count > 0;
    }

    private static bool IsLootLogHeader(string[] values)
    {
        return values.Length >= LootLogHeaderColumns.Length
               && LootLogHeaderColumns
                   .Select((columnName, index) => string.Equals(values[index], columnName, StringComparison.OrdinalIgnoreCase))
                   .All(isMatchingColumn => isMatchingColumn);
    }

    private static bool IsNonLootEventRow(string[] values)
    {
        return values.Length >= LootLogHeaderColumns.Length
               && string.IsNullOrWhiteSpace(values[3])
               && string.IsNullOrWhiteSpace(values[4])
               && string.IsNullOrWhiteSpace(values[5])
               && string.IsNullOrWhiteSpace(values[6]);
    }

    private static bool TryParseLootLogCombatEvent(string[] values, out LootLogCombatEvent combatEvent)
    {
        combatEvent = null;

        if (values is not { Length: >= 14 }
            || !TryParseLootLogTimestamp(values[0], out var utcTimestamp)
            || string.IsNullOrWhiteSpace(values[10])
            || string.IsNullOrWhiteSpace(values[12]))
        {
            return false;
        }

        combatEvent = new LootLogCombatEvent
        {
            UtcTimestamp = utcTimestamp,
            DiedName = values[10],
            DiedPlayerGuild = values[11],
            DiedPlayerAlliance = values.Length > 16 ? values[16] : string.Empty,
            KilledByName = values[12],
            KilledByGuild = values[13],
            KilledByAlliance = values.Length > 17 ? values[17] : string.Empty,
            ClusterName = values.Length > 15 ? values[15] : string.Empty
        };
        return true;
    }

    private static bool TryParseLootLogFields(string[] values, out ImportedLootLogItem lootLogItem)
    {
        lootLogItem = null;

        if (values is not { Length: >= 10 })
        {
            return false;
        }

        if (!TryParseLootLogTimestamp(values[0], out var utcPickupTime))
        {
            return false;
        }

        if (!int.TryParse(values[6], NumberStyles.Integer, CultureInfo.InvariantCulture, out var quantity) || quantity <= 0)
        {
            return false;
        }

        var item = GetLootLogItem(values[4], values[5]);
        if (item is null)
        {
            return false;
        }

        lootLogItem = new ImportedLootLogItem
        {
            UtcPickupTime = utcPickupTime,
            LootedByAlliance = values[1],
            LootedByGuild = values[2],
            LootedByName = values[3],
            Item = item,
            ItemIdentifier = string.IsNullOrWhiteSpace(values[4]) ? item.UniqueName : values[4],
            Quantity = quantity,
            LootedFromAlliance = values[7],
            LootedFromGuild = values[8],
            LootedFromName = values[9],
            ClusterName = values.Length > 15 ? values[15] : string.Empty
        };

        return !string.IsNullOrWhiteSpace(lootLogItem.LootedByName);
    }

    private static bool TryParseLootLogTimestamp(string value, out DateTime utcPickupTime)
    {
        utcPickupTime = DateTime.MinValue;

        if (DateTimeOffset.TryParse(value, CultureInfo.InvariantCulture, DateTimeStyles.AssumeUniversal, out var dateTimeOffset))
        {
            utcPickupTime = dateTimeOffset.UtcDateTime;
            return true;
        }

        if (DateTime.TryParseExact(value, SupportedFormats, CultureInfo.InvariantCulture, DateTimeStyles.AssumeUniversal | DateTimeStyles.AdjustToUniversal, out var dateTime))
        {
            utcPickupTime = dateTime;
            return true;
        }

        if (DateTime.TryParse(value, CultureInfo.InvariantCulture, DateTimeStyles.AssumeUniversal | DateTimeStyles.AdjustToUniversal, out dateTime))
        {
            utcPickupTime = dateTime;
            return true;
        }

        return false;
    }

    private static Item GetLootLogItem(string itemIdentifier, string itemName)
    {
        if (int.TryParse(itemIdentifier, NumberStyles.Integer, CultureInfo.InvariantCulture, out var itemIndex))
        {
            return ItemController.GetItemByIndex(itemIndex);
        }

        var item = ItemController.GetItemByUniqueName(itemIdentifier);
        if (item is not null)
        {
            return item;
        }

        var cleanItemIdentifier = ItemController.GetCleanUniqueName(itemIdentifier);
        if (!string.Equals(cleanItemIdentifier, itemIdentifier, StringComparison.Ordinal))
        {
            item = ItemController.GetItemByUniqueName(cleanItemIdentifier);
            if (item is not null)
            {
                return item;
            }
        }

        var enchantment = ItemController.GetItemLevel(itemIdentifier);
        return ItemController.GetItemByLocalizedName(itemName, enchantment);
    }

    private int AddLootLogItems(IReadOnlyCollection<ImportedLootLogItem> lootLogItems)
    {
        if (lootLogItems.Count <= 0)
        {
            return 0;
        }

        var keyComparer = new LootLogDuplicateKeyComparer();
        var existingItemsByKey = LootingPlayers
            .SelectMany(player => player.GetLootedItemsSnapshot())
            .Where(item => !item.IsItemFromVaultLog)
            .GroupBy(CreateLootLogDuplicateKey, keyComparer)
            .ToDictionary(group => group.Key, group => group.ToList(), keyComparer);
        var timeOffset = EstimateLootLogTimeOffset(lootLogItems, existingItemsByKey, keyComparer);
        var matchedExistingItems = new HashSet<LootedItem>();
        var addedItems = 0;

        foreach (var lootLogItem in lootLogItems)
        {
            if (TryFindDuplicateLootLogItem(lootLogItem, timeOffset, existingItemsByKey, matchedExistingItems))
            {
                continue;
            }

            AddLootLogItem(lootLogItem, timeOffset);
            addedItems++;
        }

        return addedItems;
    }

    public bool AddLootLogCombatEvent(LootLogCombatEvent combatEvent)
    {
        return combatEvent is not null && AddLootLogCombatEvents([combatEvent]) > 0;
    }

    private int AddLootLogCombatEvents(IEnumerable<LootLogCombatEvent> combatEvents)
    {
        var addedEvents = 0;

        foreach (var combatEvent in combatEvents)
        {
            if (LootLogCombatEvents.Any(existingEvent => IsSameLootLogCombatEvent(existingEvent, combatEvent)))
            {
                continue;
            }

            LootLogCombatEvents.Add(combatEvent);
            AddOrUpdateCombatPlayer(combatEvent.DiedName, combatEvent.DiedPlayerGuild, combatEvent.DiedPlayerAlliance);
            AddOrUpdateCombatPlayer(combatEvent.KilledByName, combatEvent.KilledByGuild, combatEvent.KilledByAlliance);
            addedEvents++;
        }

        RefreshLootingPlayerCombatCounts();
        return addedEvents;
    }

    private static bool IsSameLootLogCombatEvent(LootLogCombatEvent firstEvent, LootLogCombatEvent secondEvent)
    {
        return ToUtc(firstEvent.UtcTimestamp) == ToUtc(secondEvent.UtcTimestamp)
               && string.Equals(firstEvent.DiedName, secondEvent.DiedName, StringComparison.OrdinalIgnoreCase)
               && string.Equals(firstEvent.DiedPlayerGuild, secondEvent.DiedPlayerGuild, StringComparison.OrdinalIgnoreCase)
               && string.Equals(firstEvent.KilledByName, secondEvent.KilledByName, StringComparison.OrdinalIgnoreCase)
               && string.Equals(firstEvent.KilledByGuild, secondEvent.KilledByGuild, StringComparison.OrdinalIgnoreCase)
               && string.Equals(firstEvent.ClusterName, secondEvent.ClusterName, StringComparison.OrdinalIgnoreCase);
    }

    private void AddOrUpdateCombatPlayer(string playerName, string playerGuild, string playerAlliance)
    {
        if (string.IsNullOrWhiteSpace(playerName))
        {
            return;
        }

        var lootingPlayer = LootingPlayers.FirstOrDefault(player =>
            string.Equals(player.PlayerName, playerName, StringComparison.OrdinalIgnoreCase));
        if (lootingPlayer is null)
        {
            LootingPlayers.Add(new LootingPlayer
            {
                PlayerName = playerName,
                PlayerGuild = playerGuild,
                PlayerAlliance = playerAlliance,
                LootingPlayerVisibility = Visibility.Visible
            });
            return;
        }

        if (string.IsNullOrWhiteSpace(lootingPlayer.PlayerGuild) && !string.IsNullOrWhiteSpace(playerGuild))
        {
            lootingPlayer.PlayerGuild = playerGuild;
        }

        if (string.IsNullOrWhiteSpace(lootingPlayer.PlayerAlliance) && !string.IsNullOrWhiteSpace(playerAlliance))
        {
            lootingPlayer.PlayerAlliance = playerAlliance;
        }
    }

    private void RefreshLootingPlayerCombatCounts()
    {
        foreach (var lootingPlayer in LootingPlayers)
        {
            var killCount = LootLogCombatEvents.Count(combatEvent =>
                string.Equals(combatEvent.KilledByName, lootingPlayer.PlayerName, StringComparison.OrdinalIgnoreCase));
            var deathCount = LootLogCombatEvents.Count(combatEvent =>
                string.Equals(combatEvent.DiedName, lootingPlayer.PlayerName, StringComparison.OrdinalIgnoreCase));
            lootingPlayer.SetCombatCounts(killCount, deathCount);
        }
    }

    private static TimeSpan EstimateLootLogTimeOffset(
        IReadOnlyCollection<ImportedLootLogItem> lootLogItems,
        IReadOnlyDictionary<LootLogDuplicateKey, List<LootedItem>> existingItemsByKey,
        IEqualityComparer<LootLogDuplicateKey> keyComparer)
    {
        if (existingItemsByKey.Count <= 0)
        {
            return TimeSpan.Zero;
        }

        var offsetCandidates = new List<double>();
        var importedItemsByKey = lootLogItems
            .GroupBy(CreateLootLogDuplicateKey, keyComparer)
            .ToList();

        foreach (var importedItemsGroup in importedItemsByKey)
        {
            var importedItems = importedItemsGroup.ToList();
            if (importedItems.Count != 1
                || !existingItemsByKey.TryGetValue(importedItemsGroup.Key, out var existingItems))
            {
                continue;
            }

            var matchingExistingItems = existingItems
                .Where(item => AreLootLogClustersMatching(item.ClusterName, importedItems[0].ClusterName))
                .ToList();
            if (matchingExistingItems.Count != 1)
            {
                continue;
            }

            AddOffsetCandidate(offsetCandidates, matchingExistingItems[0], importedItems[0]);
        }

        if (offsetCandidates.Count <= 0)
        {
            foreach (var lootLogItem in lootLogItems)
            {
                if (!existingItemsByKey.TryGetValue(CreateLootLogDuplicateKey(lootLogItem), out var existingItems))
                {
                    continue;
                }

                var nearestOffset = existingItems
                    .Where(item => AreLootLogClustersMatching(item.ClusterName, lootLogItem.ClusterName))
                    .Select(item => (double?)(ToUtc(item.UtcPickupTime) - lootLogItem.UtcPickupTime).TotalSeconds)
                    .Where(offset => Math.Abs(offset.GetValueOrDefault()) <= LootLogOffsetSearchLimitSeconds)
                    .OrderBy(offset => Math.Abs(offset.GetValueOrDefault()))
                    .FirstOrDefault();
                if (nearestOffset.HasValue)
                {
                    offsetCandidates.Add(nearestOffset.Value);
                }
            }
        }

        if (offsetCandidates.Count <= 0)
        {
            return TimeSpan.Zero;
        }

        var dominantOffsets = offsetCandidates
            .Select(offset => offsetCandidates
                .Where(candidate => Math.Abs(candidate - offset) <= LootLogOffsetGroupingToleranceSeconds)
                .ToList())
            .OrderByDescending(offsets => offsets.Count)
            .ThenBy(offsets => offsets.Max() - offsets.Min())
            .First();
        var offsetSeconds = GetMedian(dominantOffsets);
        if (dominantOffsets.Count == 1 && Math.Abs(offsetSeconds) > LootLogSingleMatchOffsetLimitSeconds)
        {
            return TimeSpan.Zero;
        }

        return TimeSpan.FromSeconds(offsetSeconds);
    }

    private static void AddOffsetCandidate(
        ICollection<double> offsetCandidates,
        LootedItem existingItem,
        ImportedLootLogItem importedItem)
    {
        var offsetSeconds = (ToUtc(existingItem.UtcPickupTime) - importedItem.UtcPickupTime).TotalSeconds;
        if (Math.Abs(offsetSeconds) <= LootLogOffsetSearchLimitSeconds)
        {
            offsetCandidates.Add(offsetSeconds);
        }
    }

    private static double GetMedian(IReadOnlyCollection<double> values)
    {
        var orderedValues = values.OrderBy(value => value).ToList();
        var middleIndex = orderedValues.Count / 2;
        return orderedValues.Count % 2 == 0
            ? (orderedValues[middleIndex - 1] + orderedValues[middleIndex]) / 2
            : orderedValues[middleIndex];
    }

    private static bool TryFindDuplicateLootLogItem(
        ImportedLootLogItem lootLogItem,
        TimeSpan timeOffset,
        IReadOnlyDictionary<LootLogDuplicateKey, List<LootedItem>> existingItemsByKey,
        ISet<LootedItem> matchedExistingItems)
    {
        if (!existingItemsByKey.TryGetValue(CreateLootLogDuplicateKey(lootLogItem), out var existingItems))
        {
            return false;
        }

        var adjustedPickupTime = lootLogItem.UtcPickupTime.Add(timeOffset);
        var match = existingItems
            .Where(item => !matchedExistingItems.Contains(item)
                           && AreLootLogClustersMatching(item.ClusterName, lootLogItem.ClusterName))
            .Select(item => new
            {
                Item = item,
                TimeDifference = Math.Abs((ToUtc(item.UtcPickupTime) - adjustedPickupTime).TotalSeconds)
            })
            .Where(candidate => candidate.TimeDifference <= LootLogResidualTimeToleranceSeconds)
            .OrderBy(candidate => candidate.TimeDifference)
            .FirstOrDefault();
        if (match is null)
        {
            return false;
        }

        matchedExistingItems.Add(match.Item);
        return true;
    }

    private static LootLogDuplicateKey CreateLootLogDuplicateKey(LootedItem lootLogItem)
    {
        var itemIdentifier = string.IsNullOrWhiteSpace(lootLogItem.UniqueItemName)
            ? lootLogItem.Item?.UniqueName ?? lootLogItem.ItemIndex.ToString(CultureInfo.InvariantCulture)
            : lootLogItem.UniqueItemName;

        return new LootLogDuplicateKey(
            itemIdentifier,
            lootLogItem.Quantity,
            lootLogItem.LootedByName,
            lootLogItem.LootedFromName);
    }

    private static LootLogDuplicateKey CreateLootLogDuplicateKey(ImportedLootLogItem lootLogItem)
    {
        var itemIdentifier = string.IsNullOrWhiteSpace(lootLogItem.ItemIdentifier)
            ? lootLogItem.Item.UniqueName
            : lootLogItem.ItemIdentifier;

        return new LootLogDuplicateKey(
            itemIdentifier,
            lootLogItem.Quantity,
            lootLogItem.LootedByName,
            lootLogItem.LootedFromName);
    }

    private static bool AreLootLogClustersMatching(string firstClusterName, string secondClusterName)
    {
        return IsUnknownLootLogCluster(firstClusterName)
               || IsUnknownLootLogCluster(secondClusterName)
               || string.Equals(firstClusterName.Trim(), secondClusterName.Trim(), StringComparison.OrdinalIgnoreCase);
    }

    private static bool IsUnknownLootLogCluster(string clusterName)
    {
        return string.IsNullOrWhiteSpace(clusterName)
               || string.Equals(clusterName.Trim(), "Unknown", StringComparison.OrdinalIgnoreCase);
    }

    private void AddLootLogItem(ImportedLootLogItem lootLogItem, TimeSpan timeOffset)
    {
        var lootingPlayer = LootingPlayers.FirstOrDefault(x => string.Equals(x.PlayerName, lootLogItem.LootedByName, StringComparison.OrdinalIgnoreCase));
        if (lootingPlayer is not null)
        {
            UpdateLootingPlayerAffiliations(lootingPlayer, lootLogItem);
            lootingPlayer.AddLootedItem(CreateLootedItem(lootLogItem, timeOffset));
            return;
        }

        LootingPlayers.Add(new LootingPlayer()
        {
            PlayerName = lootLogItem.LootedByName,
            PlayerGuild = lootLogItem.LootedByGuild,
            PlayerAlliance = lootLogItem.LootedByAlliance,
            LootingPlayerVisibility = Visibility.Visible,
            LootedItems =
            [
                CreateLootedItem(lootLogItem, timeOffset)
            ]
        });
    }

    private static LootedItem CreateLootedItem(ImportedLootLogItem lootLogItem, TimeSpan timeOffset)
    {
        return new LootedItem
        {
            UtcPickupTime = lootLogItem.UtcPickupTime.Add(timeOffset),
            ItemIndex = lootLogItem.Item.Index,
            UniqueItemName = lootLogItem.ItemIdentifier,
            Quantity = lootLogItem.Quantity,
            LootedByName = lootLogItem.LootedByName,
            LootedFromName = lootLogItem.LootedFromName,
            LootedFromGuild = lootLogItem.LootedFromGuild,
            ClusterName = lootLogItem.ClusterName,
            IsTrash = IsTrashItem(lootLogItem.Item)
        };
    }

    private static bool IsTrashItem(Item item)
    {
        return item is null
               || item.UniqueName?.Contains("TRASH", StringComparison.OrdinalIgnoreCase) == true
               || string.Equals(item.FullItemInformation?.ShopSubCategory1, "trash", StringComparison.OrdinalIgnoreCase);
    }

    private static void UpdateLootingPlayerAffiliations(LootingPlayer lootingPlayer, ImportedLootLogItem lootLogItem)
    {
        if (string.IsNullOrWhiteSpace(lootingPlayer.PlayerGuild) && !string.IsNullOrWhiteSpace(lootLogItem.LootedByGuild))
        {
            lootingPlayer.PlayerGuild = lootLogItem.LootedByGuild;
        }

        if (string.IsNullOrWhiteSpace(lootingPlayer.PlayerAlliance) && !string.IsNullOrWhiteSpace(lootLogItem.LootedByAlliance))
        {
            lootingPlayer.PlayerAlliance = lootLogItem.LootedByAlliance;
        }
    }

    private static IEnumerable<VaultContainerLogItem> ReadVaultLogText(string chestLogText)
    {
        return TryReadVaultLogText(chestLogText, out var items) ? items : [];
    }

    private static bool TryReadVaultLogText(string chestLogText, out List<VaultContainerLogItem> items)
    {
        items = [];

        if (string.IsNullOrWhiteSpace(chestLogText))
        {
            return false;
        }

        using var reader = new StringReader(chestLogText);
        var hasDataLine = false;

        while (reader.ReadLine() is { } line)
        {
            if (string.IsNullOrWhiteSpace(line))
            {
                continue;
            }

            if (IsVaultLogHeader(line))
            {
                continue;
            }

            hasDataLine = true;
            if (!TryParseVaultLogLine(line, out var item))
            {
                return false;
            }

            items.Add(item);
        }

        return hasDataLine;
    }

    private static bool IsVaultLogHeader(string line)
    {
        var values = SplitVaultLogLine(line);
        return values.Length >= 6
               && IsAnyVaultLogColumn(values[0], ["Datum", "Date"], "@TERRITORYUI_EVENTDATE")
               && IsAnyVaultLogColumn(values[1], ["Spieler", "Player"], "@ACCESS_RIGHTS_TYPE_PLAYER", "@GUILDLOGS_PLAYER")
               && IsAnyVaultLogColumn(values[2], ["Gegenstand", "Item"], "@GOLDMARKET_LIST_HEADER_ITEM", "MARKETPLACEGUI_CATEGORY_COLUMN_ITEM")
               && IsAnyVaultLogColumn(values[3], ["Verzauberung", "Enchantment"], "@CRAFTBUILDING_TITLE_ENCHANTMENT", "@ITEMDETAILS_STATS_BONUS_ENCHANTMENT")
               && IsAnyVaultLogColumn(values[4], ["Qualität", "Qualitat", "Quality"], "@LOADOUTS_UI_MAIN_SETTING_QUALITY")
               && IsAnyVaultLogColumn(values[5], ["Anzahl", "Amount"], "@GENERIC_QUANTITY");
    }

    private static bool TryParseVaultLogLine(string line, out VaultContainerLogItem item)
    {
        item = null;
        var values = SplitVaultLogLine(line);

        if (values.Length != 6)
        {
            return false;
        }

        if (values[5].Length <= 0)
        {
            return false;
        }

        if (!TryParseVaultLogTimestamp(values[0], out var utcTimestamp))
        {
            return false;
        }

        if (!int.TryParse(values[3], NumberStyles.Integer, CultureInfo.InvariantCulture, out var enchantment))
        {
            return false;
        }

        if (!int.TryParse(values[4], NumberStyles.Integer, CultureInfo.InvariantCulture, out var quality))
        {
            return false;
        }

        if (!int.TryParse(values[5], NumberStyles.Integer, CultureInfo.InvariantCulture, out var quantity))
        {
            return false;
        }

        item = new VaultContainerLogItem
        {
            Timestamp = utcTimestamp,
            PlayerName = values[1],
            LocalizedName = values[2],
            Enchantment = enchantment,
            Quality = quality,
            Quantity = quantity
        };

        return !string.IsNullOrWhiteSpace(item.PlayerName) && !string.IsNullOrWhiteSpace(item.LocalizedName);
    }

    private static bool TryParseVaultLogTimestamp(string value, out DateTime utcTimestamp)
    {
        utcTimestamp = DateTime.MinValue;

        if (!DateTime.TryParseExact(value, SupportedFormats, CultureInfo.InvariantCulture, DateTimeStyles.AssumeUniversal | DateTimeStyles.AdjustToUniversal, out utcTimestamp))
        {
            return false;
        }

        return true;
    }

    private static DateTime ToUtc(DateTime timestamp)
    {
        return timestamp.Kind switch
        {
            DateTimeKind.Utc => timestamp,
            DateTimeKind.Local => timestamp.ToUniversalTime(),
            _ => DateTime.SpecifyKind(timestamp, DateTimeKind.Local).ToUniversalTime()
        };
    }

    private static string[] SplitVaultLogLine(string line)
    {
        var delimiter = line.Contains('\t') ? '\t' : ',';
        if (!TrySplitDelimitedLine(line, delimiter, out var values))
        {
            return [];
        }

        TrimDelimitedValues(values);
        return values;
    }

    private static bool IsAnyVaultLogColumn(string value, IReadOnlyCollection<string> expectedColumnNames, params string[] gameTranslationKeys)
    {
        return expectedColumnNames.Any(expectedColumnName => string.Equals(value, expectedColumnName, StringComparison.OrdinalIgnoreCase))
               || gameTranslationKeys
                   .SelectMany(LocalizationController.GameTranslations)
                   .Any(expectedColumnName => string.Equals(value, expectedColumnName, StringComparison.OrdinalIgnoreCase));
    }

    private static void TrimDelimitedValues(string[] values)
    {
        for (var i = 0; i < values.Length; i++)
        {
            values[i] = values[i].Trim().TrimStart('\uFEFF');
        }
    }

    private static bool TrySplitDelimitedLine(string line, char delimiter, out string[] values)
    {
        values = [];
        List<string> fields = [];
        var currentField = new StringBuilder();
        var isInsideQuotes = false;

        for (var i = 0; i < line.Length; i++)
        {
            var currentChar = line[i];

            if (currentChar == '"')
            {
                if (isInsideQuotes && i + 1 < line.Length && line[i + 1] == '"')
                {
                    currentField.Append('"');
                    i++;
                    continue;
                }

                isInsideQuotes = !isInsideQuotes;
                continue;
            }

            if (currentChar == delimiter && !isInsideQuotes)
            {
                fields.Add(currentField.ToString());
                currentField.Clear();
                continue;
            }

            currentField.Append(currentChar);
        }

        if (isInsideQuotes)
        {
            return false;
        }

        fields.Add(currentField.ToString());
        values = fields.ToArray();
        return true;
    }

    private int AddVaultLogItems(IEnumerable<VaultContainerLogItem> items)
    {
        var addedItems = 0;
        foreach (var item in items.Where(x => x.Quantity > 0))
        {
            if (VaultLogItems.Any(existingItem => IsSameVaultLogItem(existingItem, item)))
            {
                continue;
            }

            VaultLogItems.Add(item);
            addedItems++;
        }

        return addedItems;
    }

    private static bool IsSameVaultLogItem(VaultContainerLogItem firstItem, VaultContainerLogItem secondItem)
    {
        return ToUtc(firstItem.Timestamp) == ToUtc(secondItem.Timestamp)
               && string.Equals(firstItem.PlayerName, secondItem.PlayerName, StringComparison.OrdinalIgnoreCase)
               && string.Equals(firstItem.LocalizedName, secondItem.LocalizedName, StringComparison.OrdinalIgnoreCase)
               && firstItem.Enchantment == secondItem.Enchantment
               && firstItem.Quality == secondItem.Quality
               && firstItem.Quantity == secondItem.Quantity;
    }

    public Visibility IsLootComparatorInfoPopupVisible
    {
        get;
        set
        {
            field = value;
            OnPropertyChanged();
        }
    } = Visibility.Collapsed;

    public void ToggleLootComparatorInfoPopupVisibility()
    {
        IsLootComparatorInfoPopupVisible = IsLootComparatorInfoPopupVisible == Visibility.Visible ? Visibility.Collapsed : Visibility.Visible;
    }

    private void RemoveLootingPlayer(object value)
    {
        if (value is not LootingPlayer lootingPlayer)
        {
            return;
        }

        RemoveLootingPlayer(lootingPlayer);
    }

    public void RemoveLootingPlayer(LootingPlayer lootingPlayer)
    {
        if (lootingPlayer is null)
        {
            return;
        }

        RemoveVaultLogItemsForPlayer(lootingPlayer.PlayerName);
        RemoveLootLogCombatEventsForPlayer(lootingPlayer.PlayerName);
        LootingPlayers.Remove(lootingPlayer);
        RefreshLootingPlayerCombatCounts();

        foreach (var emptyPlayer in LootingPlayers
                     .Where(player => player.LootedItemCount <= 0 && !player.HasCombatEvents)
                     .ToList())
        {
            LootingPlayers.Remove(emptyPlayer);
        }

        LootingPlayersCollectionView?.Refresh();
        RefreshLootComparatorLogCounts();
    }

    private void RemoveVaultLogItemsForPlayer(string playerName)
    {
        if (string.IsNullOrWhiteSpace(playerName))
        {
            return;
        }

        var vaultItemsToRemove = VaultLogItems
            .Where(item => string.Equals(item.PlayerName, playerName, StringComparison.OrdinalIgnoreCase))
            .ToList();

        foreach (var vaultItem in vaultItemsToRemove)
        {
            VaultLogItems.Remove(vaultItem);
        }
    }

    private void RemoveLootLogCombatEventsForPlayer(string playerName)
    {
        if (string.IsNullOrWhiteSpace(playerName))
        {
            return;
        }

        foreach (var combatEvent in LootLogCombatEvents
                     .Where(item => item.IsForPlayer(playerName))
                     .ToList())
        {
            LootLogCombatEvents.Remove(combatEvent);
        }
    }

    private void CopyLootingPlayerLogs(object value)
    {
        if (value is not LootingPlayer { HasLootLogEntries: true } lootingPlayer)
        {
            return;
        }

        try
        {
            Clipboard.SetText(_lootComparatorSaveService.CreatePlayerLootLog(lootingPlayer, LootLogCombatEvents));
        }
        catch (Exception ex)
        {
            Debug.Print($"Error copying player loot logs to clipboard: {ex.Message}");
        }
    }

    public string StatusFilterSummary => IsAllStatusFilterSelected
        ? $"{LoggingTranslation.FilterStatus}: {LoggingTranslation.FilterAll}"
        : BuildFilterSummary(LoggingTranslation.FilterStatus, CountSelectedFilters(IsShowingLost, IsShowingResolved, IsShowingDonated, IsShowingTrash), 4);
    public string TierFilterSummary => IsAllTierFilterSelected
        ? $"{LoggingTranslation.FilterTier}: {LoggingTranslation.FilterAll}"
        : BuildFilterSummary(LoggingTranslation.FilterTier, CountSelectedFilters(IsShowingT1ToT3, IsShowingT4, IsShowingT5, IsShowingT6, IsShowingT7, IsShowingT8), 6);
    public string TypeFilterSummary => IsAllTypeFilterSelected
        ? $"{LoggingTranslation.FilterType}: {LoggingTranslation.FilterAll}"
        : BuildFilterSummary(LoggingTranslation.FilterType, CountSelectedFilters(IsShowingFood, IsShowingPotion, IsShowingBag, IsShowingCape, IsShowingWeapon, IsShowingArmor, IsShowingMount, IsShowingOthers), 8);
    public string GuildFilterSummary => IsAllGuildFilterSelected
        ? $"{LoggingTranslation.Guild}: {LoggingTranslation.FilterAll}"
        : BuildFilterSummary(LoggingTranslation.Guild, LootComparatorGuildFilters.Count(filter => filter.IsSelected), LootComparatorGuildFilters.Count);
    public string NotificationFilterSummary => IsAllNotificationFilterSelected
        ? $"{LoggingTranslation.Filter}: {LoggingTranslation.FilterAll}"
        : BuildFilterSummary(LoggingTranslation.Filter, Filters.Count(filter => filter.IsSelected == true), Filters.Count);
    public string TrackingSummary => BuildFilterSummary(LoggingTranslation.Tracking, CountSelectedFilters(IsTrackingPartyLootOnly, IsTrackingSilver, IsTrackingFame, IsTrackingMobLoot, IsTrackingPlayerLoot, IsTrackingKill), 6);
    public int ChestLogCount => _chestLogSourceCount;
    public int LootLogCount => _lootLogFileCount;
    public bool HasLootComparatorLogs => VaultLogItems.Count > 0
                                         || LootLogCombatEvents.Count > 0
                                         || LootingPlayers.SelectMany(player => player.GetLootedItemsSnapshot()).Any(item => !item.IsItemFromVaultLog);
    public bool CanSaveLootComparator => AppDataPaths.IsUserDataAvailable && HasLootComparatorLogs;
    public bool CanLoadLootComparatorSave => SelectedLootComparatorSave is not null;
    public bool CanDeleteLootComparatorSave => SelectedLootComparatorSave is not null;
    public string LootComparatorLogCountSummary => LocalizationController.Translation("LOOT_COMPARATOR_LOG_COUNT_SUMMARY",
        ["CHEST_COUNT", "LOOT_COUNT"],
        [ChestLogCount.ToString(CultureInfo.InvariantCulture), LootLogCount.ToString(CultureInfo.InvariantCulture)]);
    public string LootComparatorLogCountTooltip => LocalizationController.Translation("LOOT_COMPARATOR_LOG_COUNT_TOOLTIP");

    private static string BuildFilterSummary(string filterName, int selectedCount, int totalCount)
    {
        var selectedText = selectedCount switch
        {
            0 => LoggingTranslation.FilterNone,
            var count when count == totalCount => LoggingTranslation.FilterAll,
            _ => LocalizationController.Translation("LOOT_FILTER_SELECTED_COUNT",
                ["COUNT"],
                [selectedCount.ToString(CultureInfo.InvariantCulture)])
        };

        return $"{filterName}: {selectedText}";
    }

    public void RefreshLootComparatorLogCounts()
    {
        OnPropertyChanged(nameof(ChestLogCount));
        OnPropertyChanged(nameof(LootLogCount));
        OnPropertyChanged(nameof(LootComparatorLogCountSummary));
        OnPropertyChanged(nameof(LootComparatorLogCountTooltip));
        OnPropertyChanged(nameof(HasLootComparatorLogs));
        OnPropertyChanged(nameof(CanSaveLootComparator));
    }

    private void ClearLootComparatorImportEventLine()
    {
        SetLootComparatorImportEventLine(string.Empty);
    }

    private void SetLootComparatorImportEventLine(string translationKey, string fileName)
    {
        var message = LocalizationController.Translation(translationKey,
            ["FILE_NAME"],
            [fileName]);

        SetLootComparatorImportEventLine(message == translationKey ? $"{translationKey}: {fileName}" : message);
    }

    private void SetLootComparatorImportEventLine(string message)
    {
        LootComparatorImportEventLine = message;
    }

    private static int CountSelectedFilters(params bool[] values)
    {
        return values.Count(value => value);
    }

    public bool IsAllStatusFilterSelected => !(_isShowingLost || _isShowingResolved || _isShowingDonated || _isShowingTrash);
    public bool IsAllTierFilterSelected => !(_isShowingT1ToT3 || _isShowingT4 || _isShowingT5 || _isShowingT6 || _isShowingT7 || _isShowingT8);
    public bool IsAllTypeFilterSelected => !(_isShowingFood || _isShowingPotion || _isShowingBag || _isShowingCape
                                             || _isShowingWeapon || _isShowingArmor || _isShowingMount || _isShowingOthers);
    public bool IsAllGuildFilterSelected => LootComparatorGuildFilters.Count > 0
                                            && LootComparatorGuildFilters.All(filter => filter.IsSelected != true);

    public void UpdateAllStatusFilterSelection(bool isSelected)
    {
        if (isSelected)
        {
            _isShowingLost = false;
            _isShowingResolved = false;
            _isShowingDonated = false;
            _isShowingTrash = false;
            OnPropertyChanged(nameof(IsShowingLost));
            OnPropertyChanged(nameof(IsShowingResolved));
            OnPropertyChanged(nameof(IsShowingDonated));
            OnPropertyChanged(nameof(IsShowingTrash));
        }

        NotifyStatusFilterChanged();
    }

    public void UpdateAllTierFilterSelection(bool isSelected)
    {
        if (isSelected)
        {
            _isShowingT1ToT3 = false;
            _isShowingT4 = false;
            _isShowingT5 = false;
            _isShowingT6 = false;
            _isShowingT7 = false;
            _isShowingT8 = false;
            OnPropertyChanged(nameof(IsShowingT1ToT3));
            OnPropertyChanged(nameof(IsShowingT4));
            OnPropertyChanged(nameof(IsShowingT5));
            OnPropertyChanged(nameof(IsShowingT6));
            OnPropertyChanged(nameof(IsShowingT7));
            OnPropertyChanged(nameof(IsShowingT8));
        }

        NotifyTierFilterChanged();
    }

    public void UpdateAllTypeFilterSelection(bool isSelected)
    {
        if (isSelected)
        {
            _isShowingFood = false;
            _isShowingPotion = false;
            _isShowingBag = false;
            _isShowingCape = false;
            _isShowingWeapon = false;
            _isShowingArmor = false;
            _isShowingMount = false;
            _isShowingOthers = false;
            OnPropertyChanged(nameof(IsShowingFood));
            OnPropertyChanged(nameof(IsShowingPotion));
            OnPropertyChanged(nameof(IsShowingBag));
            OnPropertyChanged(nameof(IsShowingCape));
            OnPropertyChanged(nameof(IsShowingWeapon));
            OnPropertyChanged(nameof(IsShowingArmor));
            OnPropertyChanged(nameof(IsShowingMount));
            OnPropertyChanged(nameof(IsShowingOthers));
        }

        NotifyTypeFilterChanged();
    }

    public void UpdateAllGuildFilterSelection(bool isSelected)
    {
        if (isSelected)
        {
            _isUpdatingLootComparatorGuildFilters = true;
            try
            {
                foreach (var filter in LootComparatorGuildFilters.Where(filter => filter.IsSelected == true))
                {
                    filter.IsSelected = false;
                }
            }
            finally
            {
                _isUpdatingLootComparatorGuildFilters = false;
            }
        }

        NotifyGuildFilterChanged();
    }

    private void RefreshLootComparatorGuildFilters()
    {
        var wasAllSelected = IsAllGuildFilterSelected;
        var previousSelections = LootComparatorGuildFilters
            .GroupBy(filter => filter.GuildName, StringComparer.OrdinalIgnoreCase)
            .ToDictionary(group => group.Key, group => group.Last().IsSelected, StringComparer.OrdinalIgnoreCase);

        foreach (var filter in LootComparatorGuildFilters)
        {
            filter.PropertyChanged -= LootComparatorGuildFilterPropertyChanged;
        }

        LootComparatorGuildFilters.Clear();

        var guildNames = LootingPlayers
            .Select(player => player.PlayerGuild)
            .Where(guildName => !string.IsNullOrWhiteSpace(guildName))
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .OrderBy(guildName => guildName, StringComparer.OrdinalIgnoreCase);

        foreach (var guildName in guildNames)
        {
            var filter = new LootComparatorGuildFilter(guildName)
            {
                IsSelected = !wasAllSelected && (!previousSelections.TryGetValue(guildName, out var wasSelected) || wasSelected)
            };

            filter.PropertyChanged += LootComparatorGuildFilterPropertyChanged;
            LootComparatorGuildFilters.Add(filter);
        }

        OnPropertyChanged(nameof(GuildFilterSummary));
        OnPropertyChanged(nameof(IsAllGuildFilterSelected));
    }

    private void LootComparatorGuildFilterPropertyChanged(object sender, PropertyChangedEventArgs args)
    {
        if (args.PropertyName == nameof(LootComparatorGuildFilter.IsSelected))
        {
            if (_isUpdatingLootComparatorGuildFilters)
            {
                return;
            }

            NotifyGuildFilterChanged();
        }
    }

    private void NotifyStatusFilterChanged()
    {
        _ = UpdateFilteredLootedItemsAsync();
        OnPropertyChanged(nameof(StatusFilterSummary));
        OnPropertyChanged(nameof(IsAllStatusFilterSelected));
    }

    private void NotifyTierFilterChanged()
    {
        _ = UpdateFilteredLootedItemsAsync();
        OnPropertyChanged(nameof(TierFilterSummary));
        OnPropertyChanged(nameof(IsAllTierFilterSelected));
    }

    private void NotifyTypeFilterChanged()
    {
        _ = UpdateFilteredLootedItemsAsync();
        OnPropertyChanged(nameof(TypeFilterSummary));
        OnPropertyChanged(nameof(IsAllTypeFilterSelected));
    }

    private void NotifyGuildFilterChanged()
    {
        _ = UpdateFilteredLootedItemsAsync();
        OnPropertyChanged(nameof(GuildFilterSummary));
        OnPropertyChanged(nameof(IsAllGuildFilterSelected));
    }

    private static readonly string[] SupportedFormats =
    [
        "MM/dd/yyyy HH:mm:ss",
        "dd/MM/yyyy HH:mm:ss",
        "yyyy-MM-dd HH:mm:ss",
        "dd.MM.yyyy HH:mm:ss"
    ];

    private sealed class LootComparisonResult
    {
        public Dictionary<LootedItem, LootedItemStatus> Statuses { get; } = [];
        public List<LootComparisonAddition> Additions { get; } = [];
    }

    private sealed class LootComparisonAddition
    {
        public LootComparisonAddition(LootingPlayer lootingPlayer, LootedItem lootedItem, string playerName)
        {
            LootingPlayer = lootingPlayer;
            LootedItem = lootedItem;
            PlayerName = playerName;
        }

        public LootingPlayer LootingPlayer { get; }
        public LootedItem LootedItem { get; }
        public string PlayerName { get; }
    }

    private sealed class LootingPlayerSnapshot
    {
        public LootingPlayerSnapshot(LootingPlayer player, string playerName, List<LootedItem> lootedItems)
        {
            Player = player;
            PlayerName = playerName;
            LootedItems = lootedItems;
        }

        public LootingPlayer Player { get; }
        public string PlayerName { get; }
        public List<LootedItem> LootedItems { get; }
    }

    private readonly record struct LootItemKey(string PlayerName, int ItemIndex, int Quantity);

    private sealed class LootItemKeyComparer : IEqualityComparer<LootItemKey>
    {
        public bool Equals(LootItemKey x, LootItemKey y)
        {
            return x.ItemIndex == y.ItemIndex
                   && x.Quantity == y.Quantity
                   && string.Equals(x.PlayerName, y.PlayerName, StringComparison.OrdinalIgnoreCase);
        }

        public int GetHashCode(LootItemKey obj)
        {
            return HashCode.Combine(
                StringComparer.OrdinalIgnoreCase.GetHashCode(obj.PlayerName ?? string.Empty),
                obj.ItemIndex,
                obj.Quantity);
        }
    }

    private readonly record struct LootLogDuplicateKey(
        string ItemIdentifier,
        int Quantity,
        string LootedByName,
        string LootedFromName);

    private sealed class LootLogDuplicateKeyComparer : IEqualityComparer<LootLogDuplicateKey>
    {
        public bool Equals(LootLogDuplicateKey x, LootLogDuplicateKey y)
        {
            return x.Quantity == y.Quantity
                   && AreEqual(x.ItemIdentifier, y.ItemIdentifier)
                   && AreEqual(x.LootedByName, y.LootedByName)
                   && AreEqual(x.LootedFromName, y.LootedFromName);
        }

        public int GetHashCode(LootLogDuplicateKey obj)
        {
            return HashCode.Combine(
                GetStringHashCode(obj.ItemIdentifier),
                obj.Quantity,
                GetStringHashCode(obj.LootedByName),
                GetStringHashCode(obj.LootedFromName));
        }

        private static bool AreEqual(string firstValue, string secondValue)
        {
            return string.Equals(
                firstValue?.Trim(),
                secondValue?.Trim(),
                StringComparison.OrdinalIgnoreCase);
        }

        private static int GetStringHashCode(string value)
        {
            return StringComparer.OrdinalIgnoreCase.GetHashCode(value?.Trim() ?? string.Empty);
        }
    }

    private sealed class ImportedLootLogItem
    {
        public DateTime UtcPickupTime { get; init; }
        public string LootedByAlliance { get; init; }
        public string LootedByGuild { get; init; }
        public string LootedByName { get; init; }
        public Item Item { get; init; }
        public string ItemIdentifier { get; init; }
        public int Quantity { get; init; }
        public string LootedFromAlliance { get; init; }
        public string LootedFromGuild { get; init; }
        public string LootedFromName { get; init; }
        public string ClusterName { get; init; }
    }

    #endregion

    #region Bindings

    public ObservableCollection<LootingPlayer> LootingPlayers
    {
        get => _lootingPlayers;
        set
        {
            UnsubscribeLootingPlayers(_lootingPlayers);
            _lootingPlayers = value ?? [];
            SubscribeLootingPlayers(_lootingPlayers);
            OnPropertyChanged();
            RefreshLootComparatorGuildFilters();
            RefreshLootingPlayerCombatCounts();
        }
    }

    public ListCollectionView LootingPlayersCollectionView
    {
        get;
        set
        {
            field = value;
            OnPropertyChanged();
        }
    }

    public ObservableCollection<VaultContainerLogItem> VaultLogItems
    {
        get;
        set
        {
            field = value;
            OnPropertyChanged();
        }
    } = [];

    public ObservableCollection<LootLogCombatEvent> LootLogCombatEvents
    {
        get;
        set
        {
            field = value ?? [];
            OnPropertyChanged();
            RefreshLootingPlayerCombatCounts();
        }
    } = [];

    public string ChestLogText
    {
        get;
        set
        {
            field = value;
            OnPropertyChanged();
        }
    } = string.Empty;

    public string LootComparatorImportEventLine
    {
        get;
        set
        {
            field = value;
            OnPropertyChanged();
            OnPropertyChanged(nameof(LootComparatorImportEventLineVisibility));
        }
    } = string.Empty;

    public Visibility LootComparatorImportEventLineVisibility => string.IsNullOrWhiteSpace(LootComparatorImportEventLine) ? Visibility.Collapsed : Visibility.Visible;

    public ObservableCollection<LootComparatorSave> LootComparatorSaves { get; } = [];

    public LootComparatorSave SelectedLootComparatorSave
    {
        get;
        set
        {
            field = value;
            OnPropertyChanged();
            OnPropertyChanged(nameof(CanLoadLootComparatorSave));
            OnPropertyChanged(nameof(CanDeleteLootComparatorSave));
        }
    }

    public ListCollectionView GameLoggingCollectionView
    {
        get;
        set
        {
            field = value;
            OnPropertyChanged();
        }
    }

    public ObservableCollection<TrackingNotification> TrackingNotifications
    {
        get;
        set
        {
            field = value;
            OnPropertyChanged();
        }
    } = new();

    public LootLoggerStats LootLoggerStats
    {
        get;
        set
        {
            field = value;
            OnPropertyChanged();
        }
    } = new();

    public ListCollectionView TopLootersCollectionView
    {
        get;
        set
        {
            field = value;
            OnPropertyChanged();
        }
    }

    public ObservableCollection<TopLooterObject> TopLooters
    {
        get;
        set
        {
            field = value;
            OnPropertyChanged();
        }
    } = new();

    public bool IsLoggingTrackingActive
    {
        get;
        set
        {
            field = value;
            SettingsController.CurrentSettings.IsLoggingTrackingActive = field;
            OnPropertyChanged();
        }
    } = true;

    public bool IsLootComparatorTrackingActive
    {
        get;
        set
        {
            field = value;
            SettingsController.CurrentSettings.IsLootComparatorTrackingActive = field;
            OnPropertyChanged();
        }
    } = true;

    public bool IsTrackingSilver
    {
        get;
        set
        {
            field = value;

            SettingsController.CurrentSettings.IsTrackingSilver = field;
            OnPropertyChanged();
            OnPropertyChanged(nameof(TrackingSummary));
        }
    }

    public bool IsTrackingFame
    {
        get;
        set
        {
            field = value;

            SettingsController.CurrentSettings.IsTrackingFame = field;
            OnPropertyChanged();
            OnPropertyChanged(nameof(TrackingSummary));
        }
    }

    public bool IsTrackingMobLoot
    {
        get;
        set
        {
            field = value;

            SettingsController.CurrentSettings.IsTrackingMobLoot = field;
            OnPropertyChanged();
            OnPropertyChanged(nameof(TrackingSummary));
        }
    }

    public bool IsTrackingPlayerLoot
    {
        get;
        set
        {
            field = value;

            SettingsController.CurrentSettings.IsTrackingPlayerLoot = field;
            OnPropertyChanged();
            OnPropertyChanged(nameof(TrackingSummary));
        }
    } = true;

    public bool IsTrackingPartyLootOnly
    {
        get;
        set
        {
            field = value;

            SettingsController.CurrentSettings.IsTrackingPartyLootOnly = field;
            OnPropertyChanged();
            OnPropertyChanged(nameof(TrackingSummary));
        }
    }

    public bool IsTrackingKill
    {
        get;
        set
        {
            field = value;

            SettingsController.CurrentSettings.IsTrackingKill = field;
            OnPropertyChanged();
            OnPropertyChanged(nameof(TrackingSummary));
        }
    }

    public ObservableCollection<LoggingFilterObject> Filters
    {
        get;
        set
        {
            field = value;
            OnPropertyChanged();
        }
    } = new();

    public ObservableCollection<LootComparatorGuildFilter> LootComparatorGuildFilters
    {
        get;
        set
        {
            field = value;
            OnPropertyChanged();
            OnPropertyChanged(nameof(GuildFilterSummary));
            OnPropertyChanged(nameof(IsAllGuildFilterSelected));
        }
    } = new();

    public bool IsShowingLost
    {
        get => _isShowingLost;
        set
        {
            _isShowingLost = value;
            OnPropertyChanged();
            NotifyStatusFilterChanged();
        }
    }

    public bool IsShowingResolved
    {
        get => _isShowingResolved;
        set
        {
            _isShowingResolved = value;
            OnPropertyChanged();
            NotifyStatusFilterChanged();
        }
    }

    public bool IsShowingDonated
    {
        get => _isShowingDonated;
        set
        {
            _isShowingDonated = value;
            OnPropertyChanged();
            NotifyStatusFilterChanged();
        }
    }

    public bool IsShowingTrash
    {
        get => _isShowingTrash;
        set
        {
            _isShowingTrash = value;
            OnPropertyChanged();
            NotifyStatusFilterChanged();
        }
    }

    public bool IsShowingT1ToT3
    {
        get => _isShowingT1ToT3;
        set
        {
            _isShowingT1ToT3 = value;
            OnPropertyChanged();
            NotifyTierFilterChanged();
        }
    }

    public bool IsShowingT4
    {
        get => _isShowingT4;
        set
        {
            _isShowingT4 = value;
            OnPropertyChanged();
            NotifyTierFilterChanged();
        }
    }

    public bool IsShowingT5
    {
        get => _isShowingT5;
        set
        {
            _isShowingT5 = value;
            OnPropertyChanged();
            NotifyTierFilterChanged();
        }
    }

    public bool IsShowingT6
    {
        get => _isShowingT6;
        set
        {
            _isShowingT6 = value;
            OnPropertyChanged();
            NotifyTierFilterChanged();
        }
    }

    public bool IsShowingT7
    {
        get => _isShowingT7;
        set
        {
            _isShowingT7 = value;
            OnPropertyChanged();
            NotifyTierFilterChanged();
        }
    }

    public bool IsShowingT8
    {
        get => _isShowingT8;
        set
        {
            _isShowingT8 = value;
            OnPropertyChanged();
            NotifyTierFilterChanged();
        }
    }

    public bool IsShowingBag
    {
        get => _isShowingBag;
        set
        {
            _isShowingBag = value;
            OnPropertyChanged();
            NotifyTypeFilterChanged();
        }
    }

    public bool IsShowingCape
    {
        get => _isShowingCape;
        set
        {
            _isShowingCape = value;
            OnPropertyChanged();
            NotifyTypeFilterChanged();
        }
    }

    public bool IsShowingWeapon
    {
        get => _isShowingWeapon;
        set
        {
            _isShowingWeapon = value;
            OnPropertyChanged();
            NotifyTypeFilterChanged();
        }
    }

    public bool IsShowingArmor
    {
        get => _isShowingArmor;
        set
        {
            _isShowingArmor = value;
            OnPropertyChanged();
            NotifyTypeFilterChanged();
        }
    }

    public bool IsShowingFood
    {
        get => _isShowingFood;
        set
        {
            _isShowingFood = value;
            OnPropertyChanged();
            NotifyTypeFilterChanged();
        }
    }

    public bool IsShowingPotion
    {
        get => _isShowingPotion;
        set
        {
            _isShowingPotion = value;
            OnPropertyChanged();
            NotifyTypeFilterChanged();
        }
    }

    public bool IsShowingMount
    {
        get => _isShowingMount;
        set
        {
            _isShowingMount = value;
            OnPropertyChanged();
            NotifyTypeFilterChanged();
        }
    }

    public bool IsShowingOthers
    {
        get => _isShowingOthers;
        set
        {
            _isShowingOthers = value;
            OnPropertyChanged();
            NotifyTypeFilterChanged();
        }
    }

    public bool IsAllButtonsEnabled
    {
        get;
        set
        {
            field = value;
            OnPropertyChanged();
        }
    } = true;

    public bool IsCompareButtonEnabled
    {
        get => _isCompareButtonEnabled;
        set
        {
            if (_isCompareButtonEnabled == value)
            {
                return;
            }

            _isCompareButtonEnabled = value;
            OnPropertyChanged();
        }
    }

    public LoggingTranslation Translation
    {
        get;
        set
        {
            field = value;
            OnPropertyChanged();
        }
    } = new();

    public ICommand RemoveLootingPlayerCommand => field ??= new CommandHandler(RemoveLootingPlayer, true);

    public ICommand CopyLootingPlayerLogsCommand => field ??= new CommandHandler(CopyLootingPlayerLogs, true);

    #endregion

    #region Loot comparator filter

    public async Task UpdateFilteredLootedItemsAsync()
    {
        if (LootingPlayers is not { Count: > 0 })
        {
            return;
        }

        _cancellationTokenSource.Cancel();
        var cancellationTokenSource = new CancellationTokenSource();
        _cancellationTokenSource = cancellationTokenSource;

        try
        {
            await Task.Run(() => ParallelLootedItemsFilterProcess(cancellationTokenSource.Token), cancellationTokenSource.Token);
            if (cancellationTokenSource.IsCancellationRequested)
            {
                return;
            }

            ApplyLootingPlayersCollectionViewFilter();
        }
        catch (TaskCanceledException)
        {
            // ignore
        }
    }

    private void ApplyLootComparatorFilters()
    {
        if (LootingPlayers is not { Count: > 0 })
        {
            return;
        }

        _cancellationTokenSource.Cancel();
        _cancellationTokenSource = new CancellationTokenSource();
        ParallelLootedItemsFilterProcess();
        ApplyLootingPlayersCollectionViewFilter();
    }

    private void ApplyLootingPlayersCollectionViewFilter()
    {
        if (LootingPlayersCollectionView == null)
        {
            return;
        }

        LootingPlayersCollectionView.Filter = item =>
        {
            if (item is LootingPlayer lootingPlayer)
            {
                return lootingPlayer.LootingPlayerVisibility == Visibility.Visible;
            }

            return false;
        };

        LootingPlayersCollectionView.CustomSort = new LootingPlayerComparer();
        LootingPlayersCollectionView.Refresh();
    }

    public void ParallelLootedItemsFilterProcess()
    {
        ParallelLootedItemsFilterProcess(_cancellationTokenSource.Token);
    }

    private void ParallelLootedItemsFilterProcess(CancellationToken cancellationToken)
    {
        var partitioner = Partitioner.Create(LootingPlayers, EnumerablePartitionerOptions.NoBuffering);
        var guildFilters = LootComparatorGuildFilters.ToList();
        var selectedGuilds = guildFilters
            .Where(filter => filter.IsSelected)
            .Select(filter => filter.GuildName)
            .ToHashSet(StringComparer.OrdinalIgnoreCase);
        var isGuildFilterRestricted = selectedGuilds.Count > 0 && selectedGuilds.Count < guildFilters.Count;

        Parallel.ForEach(partitioner, (lootingPlayer, state) =>
        {
            if (cancellationToken.IsCancellationRequested)
            {
                state.Stop();
                return;
            }

            var itemsToProcess = lootingPlayer.GetLootedItemsSnapshot();
            var hasVisibleItems = false;

            foreach (var lootedItem in itemsToProcess)
            {
                if (cancellationToken.IsCancellationRequested)
                {
                    state.Stop();
                    return;
                }

                var visibility = Filter(lootedItem, lootingPlayer, isGuildFilterRestricted, selectedGuilds)
                    ? Visibility.Visible
                    : Visibility.Collapsed;

                lootedItem.Visibility = visibility;
                hasVisibleItems |= visibility == Visibility.Visible;
            }

            lootingPlayer.LootingPlayerVisibility = hasVisibleItems || lootingPlayer.HasCombatEvents
                ? Visibility.Visible
                : Visibility.Collapsed;
        });
    }

    public void SetPlayerVisibility(List<LootingPlayer> lootingPlayers)
    {
        foreach (LootingPlayer lootingPlayer in lootingPlayers)
        {
            var lootedItems = lootingPlayer.GetLootedItemsSnapshot();
            if (lootingPlayer.HasCombatEvents)
            {
                lootingPlayer.LootingPlayerVisibility = Visibility.Visible;
            }
            else if (lootedItems.Count > 0 && lootedItems.All(x => x.Visibility != Visibility.Visible))
            {
                lootingPlayer.LootingPlayerVisibility = Visibility.Collapsed;
            }
            else if (lootedItems.Count <= 0)
            {
                lootingPlayer.LootingPlayerVisibility = Visibility.Collapsed;
            }
            else
            {
                lootingPlayer.LootingPlayerVisibility = Visibility.Visible;
            }
        }
    }

    private bool Filter(LootedItem lootedItem, LootingPlayer lootingPlayer, bool isGuildFilterRestricted, IReadOnlySet<string> selectedGuilds)
    {
        var item = lootedItem.Item;
        return IsStatusOkay(lootedItem)
               && IsTierOkay(item)
               && IsTypeOkay(item)
               && IsGuildOkay(lootingPlayer, isGuildFilterRestricted, selectedGuilds);
    }

    private bool IsStatusOkay(LootedItem lootedItem)
    {
        if (IsAllStatusFilterSelected)
        {
            return true;
        }

        if (lootedItem.IsTrash && !_isShowingTrash)
        {
            return false;
        }

        return lootedItem.Status switch
        {
            LootedItemStatus.Lost => _isShowingLost,
            LootedItemStatus.Resolved => _isShowingResolved,
            LootedItemStatus.Donated => _isShowingDonated,
            LootedItemStatus.Unknown => true,
            LootedItemStatus.Ignored => true,
            _ => true
        };
    }

    private bool IsTierOkay(Item item)
    {
        if (IsAllTierFilterSelected)
        {
            return true;
        }

        if (item is null)
        {
            return _isShowingOthers;
        }

        if (_isShowingT1ToT3 && item.Tier is >= 1 and <= 3)
        {
            return true;
        }

        if (_isShowingT4 && item.Tier == 4)
        {
            return true;
        }

        if (_isShowingT5 && item.Tier == 5)
        {
            return true;
        }

        if (_isShowingT6 && item.Tier == 6)
        {
            return true;
        }

        if (_isShowingT7 && item.Tier == 7)
        {
            return true;
        }

        if (_isShowingT8 && item.Tier == 8)
        {
            return true;
        }

        return false;
    }

    private bool IsTypeOkay(Item item)
    {
        if (IsAllTypeFilterSelected)
        {
            return true;
        }

        var itemInformation = item?.FullItemInformation;
        if (itemInformation == null)
        {
            return _isShowingOthers;
        }

        var cat = itemInformation.ShopCategory;
        var sub1 = itemInformation.ShopSubCategory1;

        if (_isShowingFood && cat == "consumables" && sub1 is "food" or "tomes")
        {
            return true;
        }

        if (_isShowingPotion && cat == "consumables" && sub1 == "potions")
        {
            return true;
        }

        if (_isShowingMount && cat is "mounts" or "raremounts" or "battle_mount")
        {
            return true;
        }

        if (_isShowingWeapon && cat is "weapons" or "offhands")
        {
            return true;
        }

        if (_isShowingArmor && cat is "armors" or "head" or "shoes" or "gathering")
        {
            return true;
        }

        if (_isShowingOthers && cat is
                "other" or "artefacts" or "cityresources" or "furniture" or "vanity"
                or "materials" or "resources" or "labourers" or "crafting"
                or "token" or "trophies" or "farming" or "unknown")
        {
            return true;
        }

        if (_isShowingBag && cat == "accessoires" && sub1 == "bag")
        {
            return true;
        }

        if (_isShowingCape && cat == "accessoires" && sub1 == "cape")
        {
            return true;
        }

        return false;
    }

    private static bool IsGuildOkay(LootingPlayer lootingPlayer, bool isGuildFilterRestricted, IReadOnlySet<string> selectedGuilds)
    {
        if (!isGuildFilterRestricted)
        {
            return true;
        }

        return !string.IsNullOrWhiteSpace(lootingPlayer.PlayerGuild)
               && selectedGuilds.Contains(lootingPlayer.PlayerGuild);
    }

    #endregion
}
