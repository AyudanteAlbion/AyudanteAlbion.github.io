using StatisticsAnalysisTool.Common;
using StatisticsAnalysisTool.Enumerations;
using StatisticsAnalysisTool.GameFileData;
using StatisticsAnalysisTool.Localization;
using StatisticsAnalysisTool.ViewModels;
using System;
using System.Collections.Generic;
using System.Windows.Input;

namespace StatisticsAnalysisTool.Cluster;

public sealed class ClusterInfo : BaseViewModel
{
    public bool ClusterInfoFullyAvailable { get; set; }

    // Change cluster data
    public DateTime Entered { get; set; }
    public MapType MapType { get; set; } = MapType.Unknown;
    public Guid? Guid { get; set; }
    public string Index { get; set; }
    public string InstanceName { get; set; }
    public string WorldMapDataType { get; set; }
    public byte[] DungeonInformation { get; set; }
    public Tier MistsDungeonTier { get; set; }

    // Join data
    public string SourceClusterIndex { get; set; }
    public string WorldJsonType { get; private set; }
    public string File { get; private set; }

    public string UniqueName { get; private set; }
    public string UniqueClusterName { get; private set; }
    public ClusterMode ClusterMode { get; private set; }
    public AvalonTunnelType AvalonTunnelType { get; private set; }
    public Tier Tier { get; private set; }
    public string MapTypeString { get; private set; }
    public string ClusterHistoryString1 { get; private set; }
    public string ClusterHistoryString2 { get; private set; }
    public string ClusterHistoryString3 { get; private set; }
    public MistsRarity MistsRarity { get; private set; }
    public List<MapMarkerType> MapMarkers => WorldData.GetMapMarkers(Index);

    public Tier RandomDungeonTier
    {
        get;
        private set
        {
            if (field == value)
            {
                return;
            }

            field = value;
            OnPropertyChanged();
            OnPropertyChanged(nameof(RandomDungeonTierLevelToolTip));
            OnPropertyChanged(nameof(MapHistoryClipboardName));
            OnPropertyChanged(nameof(MapHistoryClipboardText));
        }
    } = Tier.Unknown;

    public int RandomDungeonLevel
    {
        get;
        private set
        {
            if (field == value)
            {
                return;
            }

            field = value;
            OnPropertyChanged();
            OnPropertyChanged(nameof(HasRandomDungeonLevelIcon));
            OnPropertyChanged(nameof(RandomDungeonTierLevelToolTip));
            OnPropertyChanged(nameof(MapHistoryClipboardName));
            OnPropertyChanged(nameof(MapHistoryClipboardText));
        }
    } = -1;

    public bool HasRandomDungeonLevelIcon => MapType == MapType.RandomDungeon && RandomDungeonLevel is >= 0 and <= 4;

    public string RandomDungeonTierLevelToolTip => $"T{GetRandomDungeonTierString()}.{GetRandomDungeonLevelString()}";

    public bool IsSelectedInMapHistory
    {
        get;
        set
        {
            field = value;
            OnPropertyChanged();
        }
    }

    public string MapHistoryNote
    {
        get;
        set
        {
            field = value;
            OnPropertyChanged();
        }
    } = string.Empty;

    public string MapHistoryClipboardName
    {
        get
        {
            var instanceClipboardName = GetInstanceMapHistoryClipboardName();
            if (!string.IsNullOrWhiteSpace(instanceClipboardName))
            {
                return instanceClipboardName;
            }

            if (!string.IsNullOrWhiteSpace(ClusterHistoryString2))
            {
                return ClusterHistoryString2;
            }

            if (!string.IsNullOrWhiteSpace(UniqueClusterName))
            {
                return UniqueClusterName;
            }

            if (!string.IsNullOrWhiteSpace(UniqueName))
            {
                return UniqueName;
            }

            if (!string.IsNullOrWhiteSpace(MapTypeString))
            {
                return MapTypeString;
            }

            if (!string.IsNullOrWhiteSpace(ClusterHistoryString1))
            {
                return ClusterHistoryString1;
            }

            return Index ?? string.Empty;
        }
    }

    public string MapHistoryClipboardText
    {
        get
        {
            var mapHistoryClipboardName = MapHistoryClipboardName;

            if (string.IsNullOrWhiteSpace(mapHistoryClipboardName))
            {
                return string.Empty;
            }

            if (string.IsNullOrWhiteSpace(MapHistoryNote))
            {
                return mapHistoryClipboardName;
            }

            return $"{mapHistoryClipboardName} [{MapHistoryNote.Trim()}]";
        }
    }

    public ICommand ToggleMapHistorySelectionCommand => field ??= new CommandHandler(ToggleMapHistorySelection, true);

    public ClusterInfo()
    {
    }

    public ClusterInfo(ClusterInfo clusterInfo)
    {
        ClusterInfoFullyAvailable = clusterInfo.ClusterInfoFullyAvailable;
        Entered = clusterInfo.Entered;
        MapType = clusterInfo.MapType;
        Guid = clusterInfo.Guid;
        Index = clusterInfo.Index;
        InstanceName = clusterInfo.InstanceName;
        WorldMapDataType = clusterInfo.WorldMapDataType;
        DungeonInformation = clusterInfo.DungeonInformation;
        SourceClusterIndex = clusterInfo.SourceClusterIndex;
        WorldJsonType = clusterInfo.WorldJsonType;
        File = clusterInfo.File;
        UniqueName = clusterInfo.UniqueName;
        UniqueClusterName = clusterInfo.UniqueClusterName;
        Tier = clusterInfo.Tier;
        MistsDungeonTier = clusterInfo.MistsDungeonTier;
        ClusterMode = clusterInfo.ClusterMode;
        AvalonTunnelType = clusterInfo.AvalonTunnelType;
        MapTypeString = clusterInfo.MapTypeString;
        MapHistoryNote = clusterInfo.MapHistoryNote;
        SetRandomDungeonTrackingInfo(clusterInfo.RandomDungeonTier, clusterInfo.RandomDungeonLevel);
        ClusterHistoryString();
    }

    public void SetClusterInfo(MapType mapType, Guid? mapGuid, string clusterIndex, string instanceName, string worldMapDataType, byte[] dungeonInformation, string mainClusterIndex)
    {
        Entered = DateTime.UtcNow;
        MapType = mapType;
        //Guid = mapGuid;
        Index = clusterIndex;
        InstanceName = instanceName;
        WorldMapDataType = worldMapDataType;
        DungeonInformation = dungeonInformation;
        MistsRarity = GetMistsRarity(dungeonInformation);
        ResetRandomDungeonTrackingInfo();

        SourceClusterIndex = mainClusterIndex;
        WorldJsonType = null;
        File = null;

        UniqueName = WorldData.GetUniqueNameOrNull(Index);
        UniqueClusterName = WorldData.GetUniqueNameOrDefault(Index) ?? InstanceName ?? string.Empty;
        MapTypeString = GetMapTypeName(MapType);
    }

    public void SetJoinClusterInfo(string index, string sourceClusterIndex, Guid? mapGuid, MapType mapType)
    {
        if (!string.IsNullOrWhiteSpace(index))
        {
            Index = index;
        }

        if (mapGuid is not null)
        {
            Guid = mapGuid;
        }

        var resolvedMapType = mapType is MapType.Unknown
            ? WorldData.GetMapType(Index)
            : mapType;
        if (resolvedMapType is not MapType.Unknown)
        {
            MapType = resolvedMapType;
        }

        SourceClusterIndex = string.IsNullOrWhiteSpace(sourceClusterIndex) ? Index : sourceClusterIndex;

        WorldJsonType = WorldData.GetWorldJsonTypeByIndex(Index) ?? WorldData.GetWorldJsonTypeByIndex(SourceClusterIndex) ?? string.Empty;
        File = WorldData.GetFileByIndex(Index) ?? WorldData.GetFileByIndex(SourceClusterIndex) ?? string.Empty;
        UniqueName = WorldData.GetUniqueNameOrNull(Index);
        UniqueClusterName = WorldData.GetUniqueNameOrDefault(Index) ?? InstanceName ?? string.Empty;
        MapTypeString = GetMapTypeName(MapType);

        Tier = GetTier(File);
        ClusterMode = GetClusterType(WorldJsonType);
        AvalonTunnelType = GetTunnelType(WorldJsonType);
        ClusterHistoryString();
    }

    public void SetRandomDungeonTrackingInfo(Tier randomDungeonTier, int randomDungeonLevel)
    {
        if (MapType != MapType.RandomDungeon)
        {
            return;
        }

        if (randomDungeonTier != Tier.Unknown)
        {
            RandomDungeonTier = randomDungeonTier;
        }

        if (randomDungeonLevel >= 0)
        {
            RandomDungeonLevel = randomDungeonLevel;
        }
    }

    private void ResetRandomDungeonTrackingInfo()
    {
        RandomDungeonTier = Tier.Unknown;
        RandomDungeonLevel = -1;
    }

    public void ClusterHistoryString()
    {
        if (MapType is MapType.StaticDungeon)
        {
            ClusterHistoryString1 = MapTypeString;
            ClusterHistoryString2 = UniqueName;
            ClusterHistoryString3 = string.Empty;
            return;
        }

        if (ClusterMode is ClusterMode.Black or ClusterMode.Red or ClusterMode.Yellow or ClusterMode.SafeArea && MapType is MapType.Unknown)
        {
            ClusterHistoryString1 = ClusterModeString(ClusterMode);
            ClusterHistoryString2 = UniqueName;
            ClusterHistoryString3 = string.Empty;
            return;
        }

        if (IsInstancedMapType(MapType))
        {
            ClusterHistoryString1 = MapTypeString;
            ClusterHistoryString2 = GetMainClusterName();
            ClusterHistoryString3 = string.Empty;
            return;
        }

        if (MapType is MapType.Arena)
        {
            ClusterHistoryString1 = MapTypeString;
            ClusterHistoryString2 = string.Empty;
            ClusterHistoryString3 = string.Empty;
            return;
        }

        if (MapType is MapType.Island or MapType.Hideout)
        {
            ClusterHistoryString1 = ClusterModeString(ClusterMode);
            ClusterHistoryString2 = InstanceName;
            ClusterHistoryString3 = string.Empty;
            return;
        }

        if (ClusterMode is ClusterMode.AvalonTunnel)
        {
            ClusterHistoryString1 = ClusterModeString(ClusterMode);
            ClusterHistoryString2 = UniqueName;
            ClusterHistoryString3 = AvalonTunnelType.ToString();
        }
    }

    private void ToggleMapHistorySelection(object _)
    {
        IsSelectedInMapHistory = !IsSelectedInMapHistory;
    }

    private static MistsRarity GetMistsRarity(byte[] infoArray)
    {
        if (infoArray is not { Length: > 0 })
        {
            return MistsRarity.Unknown;
        }

        return MistsRarityResolver.FromValue(infoArray[^1]);
    }

    public string TierRomanString
    {
        get
        {
            return Tier switch
            {
                Tier.T1 => "I",
                Tier.T2 => "II",
                Tier.T3 => "III",
                Tier.T4 => "IV",
                Tier.T5 => "V",
                Tier.T6 => "VI",
                Tier.T7 => "VII",
                Tier.T8 => "VIII",
                _ => "?"
            };
        }
    }

    public string TierString
    {
        get
        {
            return Tier switch
            {
                Tier.T1 => "T1",
                Tier.T2 => "T2",
                Tier.T3 => "T3",
                Tier.T4 => "T4",
                Tier.T5 => "T5",
                Tier.T6 => "T6",
                Tier.T7 => "T7",
                Tier.T8 => "T8",
                _ => "T?"
            };
        }
    }

    private static string ClusterModeString(ClusterMode clusterMode)
    {
        return clusterMode switch
        {
            ClusterMode.Island => LocalizationController.Translation("ISLAND"),
            ClusterMode.AvalonTunnel => LocalizationController.Translation("AVALON_ROAD"),
            ClusterMode.Black => LocalizationController.Translation("BLACK_ZONE"),
            ClusterMode.Red => LocalizationController.Translation("RED_ZONE"),
            ClusterMode.Yellow => LocalizationController.Translation("YELLOW_ZONE"),
            ClusterMode.SafeArea => LocalizationController.Translation("SAFE_AREA"),
            ClusterMode.Mists => LocalizationController.Translation("MISTS"),
            ClusterMode.Unknown => LocalizationController.Translation("UNKNOWN_ZONE"),
            _ => ""
        };
    }

    private static bool IsAvalonClusterTunnelByType(string type)
    {
        if (string.IsNullOrEmpty(type))
        {
            return false;
        }

        return type.ToUpper().Contains("TUNNEL_BLACK_LOW")
               || type.ToUpper().Contains("TUNNEL_BLACK_MEDIUM")
               || type.ToUpper().Contains("TUNNEL_BLACK_HIGH")
               || type.ToUpper().Contains("TUNNEL_LOW")
               || type.ToUpper().Contains("TUNNEL_MEDIUM")
               || type.ToUpper().Contains("TUNNEL_HIGH")
               || type.ToUpper().Contains("TUNNEL_DEEP")
               || type.ToUpper().Contains("TUNNEL_ROYAL")
               || type.ToUpper().Contains("TUNNEL_HIDEOUT");
    }

    private static Tier GetTier(string value)
    {
        if (string.IsNullOrEmpty(value))
        {
            return Tier.Unknown;
        }

        if (value.Contains("_T1_"))
        {
            return Tier.T1;
        }

        if (value.Contains("_T2_"))
        {
            return Tier.T2;
        }

        if (value.Contains("_T3_"))
        {
            return Tier.T3;
        }

        if (value.Contains("_T4_"))
        {
            return Tier.T4;
        }

        if (value.Contains("_T5_"))
        {
            return Tier.T5;
        }

        if (value.Contains("_T6_"))
        {
            return Tier.T6;
        }

        if (value.Contains("_T7_"))
        {
            return Tier.T7;
        }

        if (value.Contains("_T8_"))
        {
            return Tier.T8;
        }

        return Tier.Unknown;
    }

    private static ClusterMode GetClusterType(string type)
    {
        if (string.IsNullOrEmpty(type))
        {
            return ClusterMode.Unknown;
        }

        if (IsAvalonClusterTunnelByType(type))
        {
            return ClusterMode.AvalonTunnel;
        }

        if (type.ToUpper().Contains("SAFEAREA") || type.ToUpper().Equals("HIDEOUT") || type.ToUpper().Contains("PLAYERCITY"))
        {
            return ClusterMode.SafeArea;
        }

        if (type.ToUpper().Contains("ISLAND"))
        {
            return ClusterMode.Island;
        }

        if (type.ToUpper().Contains("YELLOW"))
        {
            return ClusterMode.Yellow;
        }

        if (type.ToUpper().Contains("RED"))
        {
            return ClusterMode.Red;
        }

        if (type.ToUpper().Contains("BLACK"))
        {
            return ClusterMode.Black;
        }

        if (type.ToUpper().Contains("MISTS"))
        {
            return ClusterMode.Mists;
        }

        return ClusterMode.Unknown;
    }

    private static AvalonTunnelType GetTunnelType(string type)
    {
        if (string.IsNullOrEmpty(type))
        {
            return AvalonTunnelType.Unknown;
        }

        if (type.ToUpper().Contains("TUNNEL_BLACK_LOW")) return AvalonTunnelType.TunnelBlackLow;

        if (type.ToUpper().Contains("TUNNEL_BLACK_MEDIUM")) return AvalonTunnelType.TunnelBlackMedium;

        if (type.ToUpper().Contains("TUNNEL_BLACK_HIGH")) return AvalonTunnelType.TunnelBlackHigh;

        if (type.ToUpper().Contains("TUNNEL_LOW")) return AvalonTunnelType.TunnelLow;

        if (type.ToUpper().Contains("TUNNEL_MEDIUM")) return AvalonTunnelType.TunnelMedium;

        if (type.ToUpper().Contains("TUNNEL_HIGH")) return AvalonTunnelType.TunnelHigh;

        if (type.ToUpper().Contains("TUNNEL_DEEP")) return AvalonTunnelType.TunnelDeep;

        if (type.ToUpper().Contains("TUNNEL_ROYAL")) return AvalonTunnelType.TunnelRoyal;

        if (type.ToUpper().Contains("TUNNEL_HIDEOUT")) return AvalonTunnelType.TunnelHideout;

        return AvalonTunnelType.Unknown;
    }

    private static string GetMapTypeName(MapType mapType)
    {
        return mapType switch
        {
            MapType.RandomDungeon => LocalizationController.Translation("DUNGEON"),
            MapType.HellGate => LocalizationController.Translation("HELLGATE"),
            MapType.CorruptedDungeon => LocalizationController.Translation("CORRUPTED_DUNGEON"),
            MapType.Island => LocalizationController.Translation("ISLAND"),
            MapType.Hideout => LocalizationController.Translation("HIDEOUT"),
            MapType.Expedition => LocalizationController.Translation("EXPEDITION"),
            MapType.Arena => LocalizationController.Translation("ARENA"),
            MapType.MistsDungeon => LocalizationController.Translation("MISTS_DUNGEON"),
            MapType.Mists => LocalizationController.Translation("MISTS"),
            MapType.AbyssalDepths => LocalizationController.Translation("ABYSSALDEPTHS"),
            MapType.DragonArea => LocalizationController.Translation("DRAGONAREA"),
            MapType.StaticDungeon => LocalizationController.Translation("STATIC_DUNGEONS"),
            _ => ""
        };
    }

    private static bool IsInstancedMapType(MapType mapType)
    {
        return mapType is MapType.RandomDungeon
            or MapType.CorruptedDungeon
            or MapType.Expedition
            or MapType.HellGate
            or MapType.Mists
            or MapType.MistsDungeon
            or MapType.AbyssalDepths
            or MapType.DragonArea;
    }

    private string GetMainClusterName()
    {
        if (string.IsNullOrWhiteSpace(SourceClusterIndex))
        {
            return string.Empty;
        }

        return WorldData.GetUniqueNameOrDefault(SourceClusterIndex) ?? SourceClusterIndex;
    }

    private string GetInstanceMapHistoryClipboardName()
    {
        return MapType switch
        {
            MapType.RandomDungeon => ComposeInstanceClipboardName($"{RandomDungeonTierLevelToolTip} Dungeon"),
            MapType.Mists => ComposeInstanceClipboardName("Mists"),
            MapType.Expedition => ComposeInstanceClipboardName("Expedition"),
            MapType.CorruptedDungeon => ComposeInstanceClipboardName("Corrupted Dungeon"),
            MapType.HellGate => ComposeInstanceClipboardName("HellGate"),
            MapType.AbyssalDepths => ComposeInstanceClipboardName("AbyssalDepths"),
            MapType.DragonArea => ComposeInstanceClipboardName("Ancient Lands"),
            _ => string.Empty
        };
    }

    private string ComposeInstanceClipboardName(string instanceName)
    {
        var mainClusterName = GetMainClusterName();

        if (string.IsNullOrWhiteSpace(mainClusterName) || mainClusterName.StartsWith("@"))
        {
            return $"({instanceName})";
        }

        return $"{mainClusterName} ({instanceName})";
    }

    private string GetRandomDungeonTierString()
    {
        if (RandomDungeonTier == Tier.Unknown)
        {
            return "?";
        }

        return ((int) RandomDungeonTier).ToString();
    }

    private string GetRandomDungeonLevelString()
    {
        if (RandomDungeonLevel is < 0 or > 4)
        {
            return "?";
        }

        return RandomDungeonLevel.ToString();
    }
}