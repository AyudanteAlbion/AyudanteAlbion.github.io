
using Serilog;
using StatisticsAnalysisTool.Backup;
using StatisticsAnalysisTool.Common;
using StatisticsAnalysisTool.Common.Shortcut;
using StatisticsAnalysisTool.Diagnostics;
using StatisticsAnalysisTool.Localization;
using StatisticsAnalysisTool.PhotonPackageParser;
using StatisticsAnalysisTool.Updater;
using StatisticsAnalysisTool.ViewModels;
using System;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls.Primitives;
using System.Windows.Input;

namespace StatisticsAnalysisTool.UserControls;

/// <summary>
/// Interaction logic for SettingsControl.xaml
/// </summary>
public partial class SettingsControl
{
    private readonly SettingsWindowViewModel _settingsWindowViewModel;

    public SettingsControl()
    {
        InitializeComponent();
        _settingsWindowViewModel = new SettingsWindowViewModel();
        DataContext = _settingsWindowViewModel;
    }

    private async void BtnSave_Click(object sender, RoutedEventArgs e)
    {
        await _settingsWindowViewModel.SaveSettingsAsync();
    }

    private void OpenToolDirectory_Click(object sender, RoutedEventArgs e)
    {
        OpenDirectory(_settingsWindowViewModel.ToolDirectory);
    }

    private void OpenUserDataDirectory_Click(object sender, RoutedEventArgs e)
    {
        OpenDirectory(_settingsWindowViewModel.UserDataDirectory);
    }

    private static void OpenDirectory(string directoryPath)
    {
        try
        {
            Directory.CreateDirectory(directoryPath);

            _ = Process.Start(new ProcessStartInfo
            {
                FileName = directoryPath,
                UseShellExecute = true
            });
        }
        catch (Exception ex)
        {
            _ = MessageBox.Show(ex.Message, LocalizationController.Translation("ERROR"));
            DebugConsole.WriteError(MethodBase.GetCurrentMethod()?.DeclaringType, ex);
            Log.Error(ex, "{message}", MethodBase.GetCurrentMethod()?.DeclaringType);
        }
    }

    private void CreateDesktopShortcut_Click(object sender, RoutedEventArgs e)
    {
        ShortcutController.CreateShortcut();
    }

    private void OpenDebugConsole_Click(object sender, RoutedEventArgs e)
    {
        DebugConsole.Attach("SAT Debug Console");
        var args = _settingsWindowViewModel.DebugConsoleFilter;
        DebugConsole.Configure(args);
    }

    private void CloseDebugConsole_Click(object sender, RoutedEventArgs e)
    {
        DebugConsole.Detach();
    }

    private void OpenEventValidation_Click(object sender, RoutedEventArgs e)
    {
        SettingsWindowViewModel.OpenEventValidationWindow();
    }

    private void ReloadSettings_OnIsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
    {
        _settingsWindowViewModel.ReloadSettings();
    }

    private async void CheckForUpdate_Click(object sender, RoutedEventArgs e)
    {
        await AutoUpdateController.CheckForUpdatesAsync();
    }

    private void ResetPlayerSelectionWithSameNameInDb_Click(object sender, RoutedEventArgs e)
    {
        _settingsWindowViewModel.ResetPlayerSelectionWithSameNameInDb();
    }

    private void ResetBackupStorageDirPath_Click(object sender, RoutedEventArgs e)
    {
        _settingsWindowViewModel.ResetBackupStorageDirPath();
    }

    private void ResetPacketFilter_Click(object sender, RoutedEventArgs e)
    {
        _settingsWindowViewModel.ResetPacketFilter();
    }

    private void MainGameFolderPathTextBox_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
        e.Handled = true;
        _settingsWindowViewModel.OpenMainGameFolderPathSelection();
    }

    private async void RestartNetworkTracking_Click(object sender, RoutedEventArgs e)
    {
        await SettingsWindowViewModel.RestartNetworkTrackingAsync();
    }

    private async void TrackingStateButton_Click(object sender, RoutedEventArgs e)
    {
        if (sender is not ToggleButton trackingStateButton)
        {
            return;
        }

        trackingStateButton.IsEnabled = false;
        try
        {
            await _settingsWindowViewModel.ToggleTrackingAsync();
        }
        finally
        {
            trackingStateButton.GetBindingExpression(ToggleButton.IsCheckedProperty)?.UpdateTarget();
            trackingStateButton.IsEnabled = true;
        }
    }

    private void PreviewAlertSound_Click(object sender, RoutedEventArgs e)
    {
        _settingsWindowViewModel.PreviewAlertSound();
    }

    private void PreviewDeathAlertSound_Click(object sender, RoutedEventArgs e)
    {
        _settingsWindowViewModel.PreviewDeathAlertSound();
    }

    private async void BackupNow_Click(object sender, RoutedEventArgs e)
    {
        _settingsWindowViewModel.IsBackupNowButtonEnabled = false;
        BackupController.Save();
        await Task.Delay(200);
        _settingsWindowViewModel.IsBackupNowButtonEnabled = true;
    }
}